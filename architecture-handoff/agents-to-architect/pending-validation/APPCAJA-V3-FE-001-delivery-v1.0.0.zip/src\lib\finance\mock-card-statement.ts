import type {
  CardStatementPreview,
  CardStatementSection,
  CardStatementGroup,
  CardStatementRow,
} from "./types";

function createRow(overrides: Partial<CardStatementRow> & { id: string; displayOrder: number; rowType: CardStatementRowType }): CardStatementRow {
  return {
    id: overrides.id,
    displayOrder: overrides.displayOrder,
    sourcePage: overrides.sourcePage ?? null,
    sectionId: overrides.sectionId ?? "main",
    sectionLabel: overrides.sectionLabel ?? "",
    groupId: overrides.groupId ?? null,
    groupLabel: overrides.groupLabel ?? null,
    rowType: overrides.rowType,
    editable: overrides.editable ?? false,
    dateRaw: overrides.dateRaw ?? null,
    markerRaw: overrides.markerRaw,
    referenceRaw: overrides.referenceRaw ?? null,
    installmentRaw: overrides.installmentRaw ?? null,
    receiptRaw: overrides.receiptRaw ?? null,
    amountPesos: overrides.amountPesos ?? null,
    amountDollars: overrides.amountDollars ?? null,
    originalText: overrides.originalText ?? "",
  };
}

function createGroup(overrides: Partial<CardStatementGroup> & { id: string; displayOrder: number; label: string; rows: CardStatementRow[] }): CardStatementGroup {
  return {
    id: overrides.id,
    displayOrder: overrides.displayOrder,
    label: overrides.label,
    cardLast4: overrides.cardLast4 ?? null,
    holderName: overrides.holderName ?? null,
    rows: overrides.rows,
    totalPesos: overrides.totalPesos ?? null,
    totalDollars: overrides.totalDollars ?? null,
  };
}

const sectionConsolidated: CardStatementSection = {
  id: "consolidated",
  displayOrder: 1,
  label: "Consolidado",
  groups: [
    createGroup({
      id: "g-6792",
      displayOrder: 1,
      label: "TARJETA 6792 Total Consumos de JAVIER SEB CORBELLA",
      cardLast4: "6792",
      holderName: "JAVIER SEB CORBELLA",
      totalPesos: 1850347.50,
      totalDollars: 161.84,
      rows: [
        createRow({ id: "r-6792-1", displayOrder: 1, rowType: "transaction", sectionId: "consolidated", groupId: "g-6792", groupLabel: "TARJETA 6792", editable: true, dateRaw: "15-Jun-26", referenceRaw: "AMAZON.COM", installmentRaw: "1/3", receiptRaw: "012345", amountPesos: 45678.90, amountDollars: null, originalText: "AMAZON.COM 1/3 45678.90" }),
        createRow({ id: "r-6792-2", displayOrder: 2, rowType: "transaction", sectionId: "consolidated", groupId: "g-6792", groupLabel: "TARJETA 6792", editable: true, dateRaw: "18-Jun-26", referenceRaw: "UBER TRIP", installmentRaw: "1/1", receiptRaw: "012346", amountPesos: 8234.50, amountDollars: null, originalText: "UBER TRIP 1/1 8234.50" }),
        createRow({ id: "r-6792-3", displayOrder: 3, rowType: "transaction", sectionId: "consolidated", groupId: "g-6792", groupLabel: "TARJETA 6792", editable: true, dateRaw: "22-Jun-26", referenceRaw: "BOOKING.COM", installmentRaw: "2/4", receiptRaw: "012347", amountPesos: 156789.00, amountDollars: 150.00, originalText: "BOOKING.COM 2/4 156789.00 USD 150.00" }),
        createRow({ id: "r-6792-4", displayOrder: 4, rowType: "transaction", sectionId: "consolidated", groupId: "g-6792", groupLabel: "TARJETA 6792", editable: true, dateRaw: "25-Jun-26", referenceRaw: "NETFLIX.COM", installmentRaw: "1/1", receiptRaw: "012348", amountPesos: 8303.49, amountDollars: 11.84, originalText: "NETFLIX.COM 1/1 8303.49 USD 11.84" }),
        createRow({ id: "r-6792-5", displayOrder: 5, rowType: "group_total", sectionId: "consolidated", groupId: "g-6792", groupLabel: "TARJETA 6792", editable: false, amountPesos: 1850347.50, amountDollars: 161.84, originalText: "Total TARJETA 6792" }),
      ],
    }),
    createGroup({
      id: "g-5884",
      displayOrder: 2,
      label: "TARJETA 5884 Total Consumos de EMILSE RITA JIMENEZ",
      cardLast4: "5884",
      holderName: "EMILSE RITA JIMENEZ",
      totalPesos: 892345.00,
      totalDollars: null,
      rows: [
        createRow({ id: "r-5884-1", displayOrder: 6, rowType: "transaction", sectionId: "consolidated", groupId: "g-5884", groupLabel: "TARJETA 5884", editable: true, dateRaw: "10-Jun-26", referenceRaw: "COTO", installmentRaw: "1/2", receiptRaw: "012350", amountPesos: 45678.90, amountDollars: null, originalText: "COTO 1/2 45678.90" }),
        createRow({ id: "r-5884-2", displayOrder: 7, rowType: "transaction", sectionId: "consolidated", groupId: "g-5884", groupLabel: "TARJETA 5884", editable: true, dateRaw: "14-Jun-26", referenceRaw: "FARMACIA", installmentRaw: "1/1", receiptRaw: "012351", amountPesos: 23456.00, amountDollars: null, originalText: "FARMACIA 1/1 23456.00" }),
        createRow({ id: "r-5884-3", displayOrder: 8, rowType: "transaction", sectionId: "consolidated", groupId: "g-5884", groupLabel: "TARJETA 5884", editable: true, dateRaw: "20-Jun-26", referenceRaw: "SHELL", installmentRaw: "1/3", receiptRaw: "012352", amountPesos: 67890.00, amountDollars: null, originalText: "SHELL 1/3 67890.00" }),
        createRow({ id: "r-5884-4", displayOrder: 9, rowType: "group_total", sectionId: "consolidated", groupId: "g-5884", groupLabel: "TARJETA 5884", editable: false, amountPesos: 892345.00, amountDollars: null, originalText: "Total TARJETA 5884" }),
      ],
    }),
    createGroup({
      id: "g-4255",
      displayOrder: 3,
      label: "TARJETA 4255 Total Consumos de JAVIER SEB CORBELLA",
      cardLast4: "4255",
      holderName: "JAVIER SEB CORBELLA",
      totalPesos: 345678.00,
      totalDollars: null,
      rows: [
        createRow({ id: "r-4255-1", displayOrder: 10, rowType: "transaction", sectionId: "consolidated", groupId: "g-4255", groupLabel: "TARJETA 4255", editable: true, dateRaw: "12-Jun-26", referenceRaw: "MERCADOLIBRE", installmentRaw: "3/6", receiptRaw: "012355", amountPesos: 156789.00, amountDollars: null, originalText: "MERCADOLIBRE 3/6 156789.00" }),
        createRow({ id: "r-4255-2", displayOrder: 11, rowType: "transaction", sectionId: "consolidated", groupId: "g-4255", groupLabel: "TARJETA 4255", editable: true, dateRaw: "19-Jun-26", referenceRaw: "DESPEGAR.COM", installmentRaw: "2/3", receiptRaw: "012356", amountPesos: 123456.00, amountDollars: null, originalText: "DESPEGAR.COM 2/3 123456.00" }),
        createRow({ id: "r-4255-3", displayOrder: 12, rowType: "transaction", sectionId: "consolidated", groupId: "g-4255", groupLabel: "TARJETA 4255", editable: true, dateRaw: "26-Jun-26", referenceRaw: "DUMONT", installmentRaw: "1/1", receiptRaw: "012357", amountPesos: 65433.00, amountDollars: null, originalText: "DUMONT 1/1 65433.00" }),
        createRow({ id: "r-4255-4", displayOrder: 13, rowType: "group_total", sectionId: "consolidated", groupId: "g-4255", groupLabel: "TARJETA 4255", editable: false, amountPesos: 345678.00, amountDollars: null, originalText: "Total TARJETA 4255" }),
      ],
    }),
    createGroup({
      id: "g-0015",
      displayOrder: 4,
      label: "TARJETA 0015 Total Consumos de LUCAS SALVA JIMENEZ",
      cardLast4: "0015",
      holderName: "LUCAS SALVA JIMENEZ",
      totalPesos: 23472.00,
      totalDollars: null,
      rows: [
        createRow({ id: "r-0015-1", displayOrder: 14, rowType: "transaction", sectionId: "consolidated", groupId: "g-0015", groupLabel: "TARJETA 0015", editable: true, dateRaw: "08-Jun-26", referenceRaw: "YPF", installmentRaw: "1/1", receiptRaw: "012360", amountPesos: 12345.00, amountDollars: null, originalText: "YPF 1/1 12345.00" }),
        createRow({ id: "r-0015-2", displayOrder: 15, rowType: "transaction", sectionId: "consolidated", groupId: "g-0015", groupLabel: "TARJETA 0015", editable: true, dateRaw: "16-Jun-26", referenceRaw: "PAMPAPLAY", installmentRaw: "1/2", receiptRaw: "012361", amountPesos: 11127.00, amountDollars: null, originalText: "PAMPAPLAY 1/2 11127.00" }),
        createRow({ id: "r-0015-3", displayOrder: 16, rowType: "group_total", sectionId: "consolidated", groupId: "g-0015", groupLabel: "TARJETA 0015", editable: false, amountPesos: 23472.00, amountDollars: null, originalText: "Total TARJETA 0015" }),
      ],
    }),
  ],
};

const sectionCharges: CardStatementSection = {
  id: "charges",
  displayOrder: 2,
  label: "Cargos e Impuestos",
  rows: [
    createRow({ id: "r-charge-1", displayOrder: 17, rowType: "tax_or_charge", sectionId: "charges", sectionLabel: "Cargos e Impuestos", editable: false, dateRaw: null, referenceRaw: "DB IVA $ PLAN V", installmentRaw: null, receiptRaw: null, amountPesos: 23456.78, amountDollars: null, originalText: "DB IVA $ PLAN V 23456.78" }),
    createRow({ id: "r-charge-2", displayOrder: 18, rowType: "tax_or_charge", sectionId: "charges", sectionLabel: "Cargos e Impuestos", editable: false, dateRaw: null, referenceRaw: "IMPUESTO DE SELLOS $", installmentRaw: null, receiptRaw: null, amountPesos: 12345.67, amountDollars: null, originalText: "IMPUESTO DE SELLOS $ 12345.67" }),
    createRow({ id: "r-charge-3", displayOrder: 19, rowType: "tax_or_charge", sectionId: "charges", sectionLabel: "Cargos e Impuestos", editable: false, dateRaw: null, referenceRaw: "IMPUESTO DE SELLOS P $", installmentRaw: null, receiptRaw: null, amountPesos: 8901.23, amountDollars: null, originalText: "IMPUESTO DE SELLOS P $ 8901.23" }),
    createRow({ id: "r-charge-4", displayOrder: 20, rowType: "tax_or_charge", sectionId: "charges", sectionLabel: "Cargos e Impuestos", editable: false, dateRaw: null, referenceRaw: "IVA RG 4240 21%", installmentRaw: null, receiptRaw: null, amountPesos: 45678.90, amountDollars: null, originalText: "IVA RG 4240 21% 45678.90" }),
    createRow({ id: "r-charge-5", displayOrder: 21, rowType: "tax_or_charge", sectionId: "charges", sectionLabel: "Cargos e Impuestos", editable: false, dateRaw: null, referenceRaw: "DB.RG 5617 30%", installmentRaw: null, receiptRaw: null, amountPesos: 123456.78, amountDollars: null, originalText: "DB.RG 5617 30% 123456.78" }),
    createRow({ id: "r-charge-6", displayOrder: 22, rowType: "final_total", sectionId: "charges", sectionLabel: "Cargos e Impuestos", editable: false, dateRaw: null, referenceRaw: "TOTAL A PAGAR", installmentRaw: null, receiptRaw: null, amountPesos: 3118842.50, amountDollars: 161.84, originalText: "TOTAL A PAGAR 3118842.50 USD 161.84" }),
  ],
};

const sectionPlanV: CardStatementSection = {
  id: "plan-v",
  displayOrder: 3,
  label: "Plan V",
  rows: [
    createRow({ id: "r-planv-1", displayOrder: 23, rowType: "legal_info", sectionId: "plan-v", sectionLabel: "Plan V", editable: false, dateRaw: null, referenceRaw: "Información sobre Plan V", installmentRaw: null, receiptRaw: null, amountPesos: null, amountDollars: null, originalText: "Plan V - Información promocional no editable" }),
  ],
};

const sectionFutureInstallments: CardStatementSection = {
  id: "future-installments",
  displayOrder: 4,
  label: "Cuotas a Vencer",
  rows: [
    createRow({ id: "r-fut-1", displayOrder: 24, rowType: "future_installment", sectionId: "future-installments", sectionLabel: "Cuotas a Vencer", editable: false, dateRaw: null, referenceRaw: "Julio/26", installmentRaw: "1/1", receiptRaw: null, amountPesos: 508000.00, amountDollars: null, originalText: "Julio/26 - Cuota mínima 508000.00" }),
    createRow({ id: "r-fut-2", displayOrder: 25, rowType: "future_installment", sectionId: "future-installments", sectionLabel: "Cuotas a Vencer", editable: false, dateRaw: null, referenceRaw: "Agosto/26", installmentRaw: "1/1", receiptRaw: null, amountPesos: 520000.00, amountDollars: null, originalText: "Agosto/26 - Proyección 520000.00" }),
    createRow({ id: "r-fut-3", displayOrder: 26, rowType: "future_installment", sectionId: "future-installments", sectionLabel: "Cuotas a Vencer", editable: false, dateRaw: null, referenceRaw: "Setiembre/26", installmentRaw: "1/1", receiptRaw: null, amountPesos: 535000.00, amountDollars: null, originalText: "Setiembre/26 - Proyección 535000.00" }),
    createRow({ id: "r-fut-4", displayOrder: 27, rowType: "future_installment", sectionId: "future-installments", sectionLabel: "Cuotas a Vencer", editable: false, dateRaw: null, referenceRaw: "Octubre/26", installmentRaw: "1/1", receiptRaw: null, amountPesos: 548000.00, amountDollars: null, originalText: "Octubre/26 - Proyección 548000.00" }),
    createRow({ id: "r-fut-5", displayOrder: 28, rowType: "future_installment", sectionId: "future-installments", sectionLabel: "Cuotas a Vencer", editable: false, dateRaw: null, referenceRaw: "Noviembre/26", installmentRaw: "1/1", receiptRaw: null, amountPesos: 560000.00, amountDollars: null, originalText: "Noviembre/26 - Proyección 560000.00" }),
    createRow({ id: "r-fut-6", displayOrder: 29, rowType: "future_installment", sectionId: "future-installments", sectionLabel: "Cuotas a Vencer", editable: false, dateRaw: null, referenceRaw: "Diciembre/26", installmentRaw: "1/1", receiptRaw: null, amountPesos: 575000.00, amountDollars: null, originalText: "Diciembre/26 - Proyección 575000.00" }),
    createRow({ id: "r-fut-7", displayOrder: 30, rowType: "future_installment", sectionId: "future-installments", sectionLabel: "Cuotas a Vencer", editable: false, dateRaw: null, referenceRaw: "A partir de Enero/27", installmentRaw: "1/1", receiptRaw: null, amountPesos: null, amountDollars: null, originalText: "A partir de Enero/27 - Sujeto a consumos futuros" }),
  ],
};

export const mockCardStatementPreview: CardStatementPreview = {
  id: "preview-1",
  sourceFileName: "Resumen_Tarjeta_Galicia_Visa_Julio2026.pdf",
  sourceKind: "pdf",
  documentKind: "credit_card_statement",
  bankName: "Galicia",
  brandName: "Visa",
  statementNumber: "001/2026",
  accountNumber: "******1234",
  holderName: "JAVIER SEB CORBELLA",
  periodLabel: "Julio 2026",
  totals: {
    totalPesos: 3118842.50,
    totalDollars: 161.84,
    minimumPaymentPesos: 508000.00,
  },
  billingCycle: [
    { displayOrder: 1, label: "Cierre anterior", valueRaw: "28-May-26" },
    { displayOrder: 2, label: "Vencimiento anterior", valueRaw: "05-Jun-26" },
    { displayOrder: 3, label: "Cierre actual", valueRaw: "02-Jul-26" },
    { displayOrder: 4, label: "Vencimiento actual", valueRaw: "13-Jul-26" },
    { displayOrder: 5, label: "Próximo cierre", valueRaw: "30-Jul-26" },
    { displayOrder: 6, label: "Próximo vencimiento", valueRaw: "07-Ago-26" },
  ],
  sections: [sectionConsolidated, sectionCharges, sectionPlanV, sectionFutureInstallments],
};

export const mockAcceptedCardStatement = {
  ...mockCardStatementPreview,
  id: "accepted-1",
  totals: {
    totalPesos: 3118842.50,
    totalDollars: 161.84,
    minimumPaymentPesos: 508000.00,
  },
  updatedValues: [
    { label: "Total Pesos", previousValue: "$ 3.118.842,50", newValue: "$ 3.118.842,50" },
    { label: "Total Dólares", previousValue: "U$D 161,84", newValue: "U$D 161,84" },
    { label: "Pago Mínimo", previousValue: "$ 508.000,00", newValue: "$ 508.000,00" },
    { label: "Consumos Confirmados", previousValue: 24, newValue: 24 },
    { label: "Cuotas Pendientes", previousValue: 12, newValue: 8 },
    { label: "Próximo Vencimiento", previousValue: "13-Jul-26", newValue: "13-Jul-26" },
  ],
};
