"use client";

import { useFinanceUI } from "@/lib/finance/ui-store";
import { DashboardSection } from "./dashboard-section";
import { MovimientosSection } from "./movimientos-section";
import { TarjetasSection } from "./tarjetas-section";
import { PresupuestosSection } from "./presupuestos-section";
import { ObjetivosSection } from "./objetivos-section";
import { ReportesSection } from "./reportes-section";
import { ConfiguracionSection } from "./configuracion-section";
import { LoadingState, EmptyState, ErrorState } from "../dashboard/ui-states";

/** Router de secciones que respeta el estado de UI (loading/empty/error). */
export function SectionRouter() {
  const section = useFinanceUI((s) => s.section);
  const mode = useFinanceUI((s) => s.mode);
  const setMode = useFinanceUI((s) => s.setMode);

  if (mode === "loading") return <LoadingState />;
  if (mode === "error")
    return <ErrorState onRetry={() => setMode("normal")} />;
  if (mode === "empty")
    return (
      <EmptyState
        title="Sin datos para mostrar"
        description="No encontramos información para este período. Probá con otro rango de fechas."
      />
    );

  switch (section) {
    case "dashboard":
      return <DashboardSection />;
    case "movimientos":
      return <MovimientosSection />;
    case "tarjetas":
      return <TarjetasSection />;
    case "presupuestos":
      return <PresupuestosSection />;
    case "objetivos":
      return <ObjetivosSection />;
    case "reportes":
      return <ReportesSection />;
    case "configuracion":
      return <ConfiguracionSection />;
    default:
      return <DashboardSection />;
  }
}
