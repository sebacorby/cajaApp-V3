import {
  LayoutDashboard,
  ArrowLeftRight,
  CreditCard,
  Wallet,
  Target,
  BarChart3,
  Settings,
  type LucideIcon,
} from "lucide-react";
import type { SectionId } from "@/lib/finance/ui-store";

export interface NavItem {
  id: SectionId;
  label: string;
  icon: LucideIcon;
  description: string;
}

export const NAV_ITEMS: NavItem[] = [
  { id: "dashboard", label: "Inicio", icon: LayoutDashboard, description: "Resumen financiero general" },
  { id: "movimientos", label: "Movimientos", icon: ArrowLeftRight, description: "Historial de ingresos y gastos" },
  { id: "tarjetas", label: "Tarjetas", icon: CreditCard, description: "Resumen, cuotas y consumos futuros" },
  { id: "presupuestos", label: "Presupuestos", icon: Wallet, description: "Límites por categoría" },
  { id: "objetivos", label: "Objetivos", icon: Target, description: "Metas de ahorro" },
  { id: "reportes", label: "Reportes", icon: BarChart3, description: "Análisis y evolución" },
  { id: "configuracion", label: "Configuración", icon: Settings, description: "Preferencias de cuenta" },
];
