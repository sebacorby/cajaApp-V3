"use client";

import { useState } from "react";
import { CreditCard, Upload, Plus, Check, X, AlertCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Sheet, SheetContent, SheetDescription, SheetFooter, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { mockCardStatementPreview, mockAcceptedCardStatement } from "@/lib/finance/mock-card-statement";
import { formatCurrencyARSWithDecimals, formatCurrencyUSDPlain } from "@/lib/finance/format";
import type { CardStatementPreview, CardStatementSection, CardStatementGroup, CardStatementRow } from "@/lib/finance/types";

type UIState = "initial" | "preview" | "accepted";

export function TarjetasSection() {
  const [uiState, setUiState] = useState<UIState>("initial");
  const [preview, setPreview] = useState<CardStatementPreview | null>(null);
  const [editedRows, setEditedRows] = useState<Map<string, Partial<CardStatementRow>>>(new Map());
  const [hasPendingChanges, setHasPendingChanges] = useState(false);
  const [showManualPurchase, setShowManualPurchase] = useState(false);

  function handleLoadPreview() {
    setPreview(mockCardStatementPreview);
    setEditedRows(new Map());
    setHasPendingChanges(false);
    setUiState("preview");
  }

  function handleCellEdit(rowId: string, field: keyof CardStatementRow, value: string | number | null) {
    setEditedRows((prev) => {
      const newMap = new Map(prev);
      const existing = newMap.get(rowId) || {};
      newMap.set(rowId, { ...existing, [field]: value });
      return newMap;
    });
    setHasPendingChanges(true);
  }

  function getEditedRow(row: CardStatementRow): CardStatementRow {
    const edits = editedRows.get(row.id);
    if (!edits) return row;
    return { ...row, ...edits };
  }

  function handleAccept() {
    setUiState("accepted");
    setHasPendingChanges(false);
  }

  function handleDiscard() {
    setEditedRows(new Map());
    setHasPendingChanges(false);
    setUiState("initial");
    setPreview(null);
  }

  function handleAddManualPurchase(formData: FormData) {
    setShowManualPurchase(false);
  }

  if (uiState === "initial") {
    return (
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Tarjetas</h1>
          <p className="text-muted-foreground">
            Importá un resumen PDF, revisá los datos extraídos y aceptalos antes de guardar.
          </p>
        </div>

        <Card className="max-w-lg">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Upload className="h-5 w-5" />
              Importar resumen
            </CardTitle>
            <CardDescription>
              En esta etapa sólo está soportado PDF. CSV e imágenes quedan para próximas features.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Button onClick={handleLoadPreview} className="w-full">
              <Upload className="mr-2 h-4 w-4" />
              Importar resumen PDF
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (uiState === "accepted") {
    return (
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Tarjetas</h1>
          <p className="text-muted-foreground">
            Resumen aceptado. Los datos fueron enviados al backend para procesamiento.
          </p>
        </div>

        <div className="rounded-lg border bg-card text-card-foreground shadow-sm">
          <div className="flex items-center gap-2 p-4 border-b">
            <Check className="h-5 w-5 text-green-600" />
            <span className="font-medium">Datos aceptados exitosamente</span>
          </div>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Valores actualizados</CardTitle>
            <CardDescription>Vista consolidada tras procesamiento del backend</CardDescription>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Concepto</TableHead>
                  <TableHead className="text-right">Valor Anterior</TableHead>
                  <TableHead className="text-right">Valor Nuevo</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {mockAcceptedCardStatement.updatedValues.map((item, idx) => (
                  <TableRow key={idx}>
                    <TableCell className="font-medium">{item.label}</TableCell>
                    <TableCell className="text-right tabular-nums text-muted-foreground">{item.previousValue}</TableCell>
                    <TableCell className="text-right tabular-nums">{item.newValue}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        <div className="flex gap-4">
          <Button variant="outline" onClick={handleDiscard}>
            <X className="mr-2 h-4 w-4" />
            Descartar y volver
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Tarjetas</h1>
        <p className="text-muted-foreground">
          Revisá los datos extraídos del resumen. Las filas editables permiten correcciones antes de aceptar.
        </p>
      </div>

      {hasPendingChanges && (
        <div className="rounded-lg border border-yellow-200 bg-yellow-50 p-3 text-sm">
          <div className="flex items-center gap-2 text-yellow-800">
            <AlertCircle className="h-4 w-4" />
            <span className="font-medium">Hay cambios pendientes sin guardar</span>
          </div>
        </div>
      )}

      <div className="grid gap-4 md:grid-cols-3 lg:grid-cols-6">
        <Card>
          <CardContent className="pt-4">
            <div className="text-2xl font-bold tabular-nums">
              {preview?.totals.totalPesos != null ? formatCurrencyARSWithDecimals(preview.totals.totalPesos) : "-"}
            </div>
            <p className="text-xs text-muted-foreground">Total en Pesos</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-4">
            <div className="text-2xl font-bold tabular-nums">
              {preview?.totals.totalDollars != null ? `U$D ${formatCurrencyUSDPlain(preview.totals.totalDollars)}` : "-"}
            </div>
            <p className="text-xs text-muted-foreground">Total en Dólares</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-4">
            <div className="text-2xl font-bold tabular-nums">
              {preview?.totals.minimumPaymentPesos != null ? formatCurrencyARSWithDecimals(preview.totals.minimumPaymentPesos) : "-"}
            </div>
            <p className="text-xs text-muted-foreground">Pago Mínimo</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-4">
            <div className="text-sm font-medium">Vencimiento actual</div>
            <p className="text-xs text-muted-foreground">
              {preview?.billingCycle.find(b => b.label === "Vencimiento actual")?.valueRaw ?? "-"}
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-4">
            <div className="text-sm font-medium">Próximo cierre</div>
            <p className="text-xs text-muted-foreground">
              {preview?.billingCycle.find(b => b.label === "Próximo cierre")?.valueRaw ?? "-"}
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-4">
            <div className="text-sm font-medium">Próximo vencimiento</div>
            <p className="text-xs text-muted-foreground">
              {preview?.billingCycle.find(b => b.label === "Próximo vencimiento")?.valueRaw ?? "-"}
            </p>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Ciclo de Facturación</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-3 gap-4 md:grid-cols-6">
            {preview?.billingCycle
              .slice()
              .sort((a, b) => a.displayOrder - b.displayOrder)
              .map((item) => (
                <div key={item.label} className="text-center">
                  <div className="text-xs text-muted-foreground">{item.label}</div>
                  <div className="font-medium tabular-nums">{item.valueRaw}</div>
                </div>
              ))}
          </div>
        </CardContent>
      </Card>

      <div className="flex items-center justify-between">
        <h2 className="text-lg font-semibold">Detalle de Consumos</h2>
        <Sheet open={showManualPurchase} onOpenChange={setShowManualPurchase}>
          <SheetTrigger asChild>
            <Button size="sm">
              <Plus className="mr-1 h-4 w-4" />
              Compra manual
            </Button>
          </SheetTrigger>
          <SheetContent>
            <SheetHeader>
              <SheetTitle>Agregar compra manual</SheetTitle>
              <SheetDescription>
                Registrar una compra del mes en curso. El cálculo de cuotas será realizado por el backend.
              </SheetDescription>
            </SheetHeader>
            <form action={handleAddManualPurchase} className="grid gap-4 py-4">
              <div className="grid gap-2">
                <Label htmlFor="description">Descripción / Comercio</Label>
                <Input id="description" name="description" placeholder="Nombre del comercio" />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="date">Fecha</Label>
                <Input id="date" name="date" type="date" />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="grid gap-2">
                  <Label htmlFor="amount">Monto</Label>
                  <Input id="amount" name="amount" type="number" placeholder="0.00" />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="currency">Moneda</Label>
                  <Select name="currency" defaultValue="ARS">
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="ARS">ARS</SelectItem>
                      <SelectItem value="USD">USD</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="grid gap-2">
                <Label htmlFor="installments">Cantidad de cuotas</Label>
                <Input id="installments" name="installments" type="number" min="1" placeholder="1" />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="card">Tarjeta</Label>
                <Select name="card" defaultValue="6792">
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="6792">6792 - JAVIER SEB CORBELLA</SelectItem>
                    <SelectItem value="5884">5884 - EMILSE RITA JIMENEZ</SelectItem>
                    <SelectItem value="4255">4255 - JAVIER SEB CORBELLA</SelectItem>
                    <SelectItem value="0015">0015 - LUCAS SALVA JIMENEZ</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="grid gap-2">
                <Label htmlFor="note">Observación (opcional)</Label>
                <Input id="note" name="note" placeholder="Agregar nota..." />
              </div>
              <SheetFooter>
                <Button type="submit">Agregar</Button>
              </SheetFooter>
            </form>
          </SheetContent>
        </Sheet>
      </div>

      <StatementGrid
        sections={preview?.sections ?? []}
        getEditedRow={getEditedRow}
        onCellEdit={handleCellEdit}
      />

      <div className="flex gap-4">
        <Button onClick={handleAccept}>
          <Check className="mr-2 h-4 w-4" />
          Aceptar datos
        </Button>
        <Button variant="outline" onClick={handleDiscard}>
          <X className="mr-2 h-4 w-4" />
          Descartar cambios
        </Button>
      </div>
    </div>
  );
}

function StatementGrid({
  sections,
  getEditedRow,
  onCellEdit,
}: {
  sections: CardStatementSection[];
  getEditedRow: (row: CardStatementRow) => CardStatementRow;
  onCellEdit: (rowId: string, field: keyof CardStatementRow, value: string | number | null) => void;
}) {
  const [pendingBackendCalculation, setPendingBackendCalculation] = useState<CardStatementRow[]>([]);

  return (
    <div className="space-y-6">
      {sections.map((section) => (
        <Card key={section.id}>
          <CardHeader className="py-3">
            <CardTitle className="text-base">{section.label}</CardTitle>
          </CardHeader>
          <CardContent className="px-0">
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="hover:bg-transparent">
                    <TableHead className="w-[100px]">Fecha</TableHead>
                    <TableHead className="w-[40px]">Marca</TableHead>
                    <TableHead>Referencia</TableHead>
                    <TableHead className="w-[80px]">Cuota</TableHead>
                    <TableHead className="w-[100px]">Comprobante</TableHead>
                    <TableHead className="text-right">Pesos</TableHead>
                    <TableHead className="text-right">Dólares</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {section.groups?.map((group) => (
                    <GroupRows
                      key={group.id}
                      group={group}
                      getEditedRow={getEditedRow}
                      onCellEdit={onCellEdit}
                    />
                  ))}
                  {section.rows?.map((row) => (
                    <RowCell
                      key={row.id}
                      row={getEditedRow(row)}
                      onCellEdit={onCellEdit}
                    />
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}

function GroupRows({
  group,
  getEditedRow,
  onCellEdit,
}: {
  group: CardStatementGroup;
  getEditedRow: (row: CardStatementRow) => CardStatementRow;
  onCellEdit: (rowId: string, field: keyof CardStatementRow, value: string | number | null) => void;
}) {
  return (
    <>
      <TableRow className="bg-muted/50 font-medium">
        <TableCell colSpan={5} className="py-2">
          {group.label}
        </TableCell>
        <TableCell className="text-right tabular-nums font-bold">
          {group.totalPesos != null ? formatCurrencyARSWithDecimals(group.totalPesos) : "-"}
        </TableCell>
        <TableCell className="text-right tabular-nums font-bold">
          {group.totalDollars != null ? formatCurrencyUSDPlain(group.totalDollars) : "-"}
        </TableCell>
      </TableRow>
      {group.rows.map((row) => (
        <RowCell
          key={row.id}
          row={getEditedRow(row)}
          onCellEdit={onCellEdit}
        />
      ))}
    </>
  );
}

function RowCell({
  row,
  onCellEdit,
}: {
  row: CardStatementRow;
  onCellEdit: (rowId: string, field: keyof CardStatementRow, value: string | number | null) => void;
}) {
  const isEditable = row.editable;
  const isGroupTotal = row.rowType === "group_total";
  const isFinalTotal = row.rowType === "final_total";
  const isHeader = row.rowType === "section_header" || row.rowType === "table_header";
  const isNonEditable = row.rowType === "tax_or_charge" || row.rowType === "future_installment" || row.rowType === "legal_info";

  if (isHeader) return null;

  if (isGroupTotal || isFinalTotal) {
    return (
      <TableRow className={`${isFinalTotal ? "bg-emerald-50 font-bold" : "bg-muted/30 font-semibold"}`}>
        <TableCell className={isFinalTotal ? "text-emerald-700" : ""}>
          {row.dateRaw ?? ""}
        </TableCell>
        <TableCell>{row.markerRaw ?? ""}</TableCell>
        <TableCell className={isFinalTotal ? "text-emerald-700" : ""}>
          {row.referenceRaw ?? ""}
        </TableCell>
        <TableCell>{row.installmentRaw ?? ""}</TableCell>
        <TableCell>{row.receiptRaw ?? ""}</TableCell>
        <TableCell className={`text-right tabular-nums ${isFinalTotal ? "text-emerald-700" : ""}`}>
          {row.amountPesos != null ? formatCurrencyARSWithDecimals(row.amountPesos) : "-"}
        </TableCell>
        <TableCell className={`text-right tabular-nums ${isFinalTotal ? "text-emerald-700" : ""}`}>
          {row.amountDollars != null ? formatCurrencyUSDPlain(row.amountDollars) : "-"}
        </TableCell>
      </TableRow>
    );
  }

  if (!isEditable) {
    return (
      <TableRow className={`${isNonEditable ? "bg-muted/10 text-muted-foreground" : ""}`}>
        <TableCell>{row.dateRaw ?? ""}</TableCell>
        <TableCell>{row.markerRaw ?? ""}</TableCell>
        <TableCell>{row.referenceRaw ?? ""}</TableCell>
        <TableCell>{row.installmentRaw ?? ""}</TableCell>
        <TableCell>{row.receiptRaw ?? ""}</TableCell>
        <TableCell className="text-right tabular-nums">
          {row.amountPesos != null ? formatCurrencyARSWithDecimals(row.amountPesos) : "-"}
        </TableCell>
        <TableCell className="text-right tabular-nums">
          {row.amountDollars != null ? formatCurrencyUSDPlain(row.amountDollars) : "-"}
        </TableCell>
      </TableRow>
    );
  }

  return (
    <TableRow className="hover:bg-muted/30">
      <TableCell>
        <Input
          className="h-8 w-[100px] text-xs"
          value={row.dateRaw ?? ""}
          onChange={(e) => onCellEdit(row.id, "dateRaw", e.target.value)}
        />
      </TableCell>
      <TableCell>
        <Input
          className="h-8 w-[40px] text-xs"
          value={row.markerRaw ?? ""}
          onChange={(e) => onCellEdit(row.id, "markerRaw", e.target.value)}
        />
      </TableCell>
      <TableCell>
        <Input
          className="h-8 text-xs"
          value={row.referenceRaw ?? ""}
          onChange={(e) => onCellEdit(row.id, "referenceRaw", e.target.value)}
        />
      </TableCell>
      <TableCell>
        <Input
          className="h-8 w-[80px] text-xs"
          value={row.installmentRaw ?? ""}
          onChange={(e) => onCellEdit(row.id, "installmentRaw", e.target.value)}
        />
      </TableCell>
      <TableCell>
        <Input
          className="h-8 w-[100px] text-xs"
          value={row.receiptRaw ?? ""}
          onChange={(e) => onCellEdit(row.id, "receiptRaw", e.target.value)}
        />
      </TableCell>
      <TableCell>
        <Input
          className="h-8 w-[120px] text-right text-xs tabular-nums"
          type="number"
          value={row.amountPesos ?? ""}
          onChange={(e) => onCellEdit(row.id, "amountPesos", e.target.value === "" ? null : Number(e.target.value))}
        />
      </TableCell>
      <TableCell>
        <Input
          className="h-8 w-[80px] text-right text-xs tabular-nums"
          type="number"
          value={row.amountDollars ?? ""}
          onChange={(e) => onCellEdit(row.id, "amountDollars", e.target.value === "" ? null : Number(e.target.value))}
        />
      </TableCell>
    </TableRow>
  );
}
