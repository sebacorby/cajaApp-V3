import Fastify, { FastifyInstance } from "fastify";
import cors from "@fastify/cors";
import multipart from "@fastify/multipart";
import { env } from "./config/env.js";
import { logger } from "./shared/logger.js";
import { healthRoutes } from "./modules/health/health.routes.js";
import { cardsRoutes } from "./modules/cards/cards.routes.js";
import { importsRoutes } from "./modules/imports/imports.routes.js";
import { manualPurchasesRoutes } from "./modules/manual-purchases/manual-purchases.routes.js";
import { AppError } from "./shared/errors.js";

export async function buildApp(): Promise<FastifyInstance> {
  const app = Fastify({
    logger: false,
  });

  await app.register(cors, {
    origin: true,
    credentials: true,
  });

  await app.register(multipart, {
    limits: {
      fileSize: env.MAX_UPLOAD_BYTES,
    },
  });

  app.setErrorHandler((error, request, reply) => {
    logger.error({ error: String(error), url: request.url, method: request.method }, "Request error");

    if (error instanceof AppError) {
      return reply.status(error.statusCode).send({
        code: error.code,
        message: error.message,
      });
    }

    const validationError = error as { validation?: unknown; message?: string };
    if (validationError.validation) {
      return reply.status(400).send({
        code: "VALIDATION_ERROR",
        message: validationError.message || "Validation error",
      });
    }

    return reply.status(500).send({
      code: "INTERNAL_ERROR",
      message: env.NODE_ENV === "development" ? String((error as { message?: string }).message || error) : "Internal server error",
    });
  });

  await app.register(healthRoutes);
  await app.register(cardsRoutes);
  await app.register(importsRoutes);
  await app.register(manualPurchasesRoutes);

  return app;
}
