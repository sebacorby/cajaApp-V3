import { env } from "../../config/env.js";
import { logger } from "../../shared/logger.js";
import { AiProviderError } from "../../shared/errors.js";
import crypto from "crypto";

export interface OllamaRequest {
  model: string;
  prompt: string;
  stream: boolean;
}

export interface OllamaResponse {
  model: string;
  response: string;
  done: boolean;
  context?: number[];
  total_duration?: number;
  load_duration?: number;
  prompt_eval_count?: number;
  prompt_eval_duration?: number;
  eval_count?: number;
  eval_duration?: number;
}

export class OllamaClient {
  private apiKey: string;
  private baseUrl: string;
  private timeout: number;
  private maxRetries: number;

  constructor() {
    this.apiKey = env.OLLAMA_API_KEY;
    this.baseUrl = env.OLLAMA_BASE_URL;
    this.timeout = env.OLLAMA_TIMEOUT_MS;
    this.maxRetries = env.OLLAMA_MAX_RETRIES;
  }

  async generate(prompt: string, model?: string): Promise<OllamaResponse> {
    if (env.AI_MOCK_MODE) {
      throw new AiProviderError("AI_MOCK_MODE=true but OllamaClient.generate() was called. Use MockAiExtractionService instead.");
    }

    const targetModel = model || env.OLLAMA_MODEL;
    if (!targetModel) {
      throw new AiProviderError("OLLAMA_MODEL not configured and AI_MOCK_MODE is false");
    }

    const startTime = Date.now();
    let lastError: Error | null = null;
    let attempts = 0;

    for (attempts = 0; attempts <= this.maxRetries; attempts++) {
      try {
        const response = await this.doRequest(prompt, targetModel);
        const duration = Date.now() - startTime;

        logger.info({
          model: targetModel,
          duration,
          status: "success",
          promptHash: crypto.createHash("sha256").update(prompt).digest("hex").slice(0, 8),
          responseHash: crypto.createHash("sha256").update(response.response).digest("hex").slice(0, 8),
          retries: attempts,
        }, "Ollama request completed");

        return response;
      } catch (error) {
        lastError = error instanceof Error ? error : new Error(String(error));
        logger.warn({ attempt: attempts + 1, maxRetries: this.maxRetries, error: lastError.message }, "Ollama request failed, retrying...");
      }
    }

    logger.error({
      model: targetModel,
      attempts,
      error: lastError?.message,
    }, "Ollama request failed after all retries");

    throw new AiProviderError(`Ollama request failed after ${attempts} attempts: ${lastError?.message}`);
  }

  private async doRequest(prompt: string, model: string): Promise<OllamaResponse> {
    const headers: Record<string, string> = {
      "Content-Type": "application/json",
    };

    if (this.apiKey) {
      headers["Authorization"] = `Bearer ${this.apiKey}`;
    }

    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), this.timeout);

    try {
      const response = await fetch(`${this.baseUrl}/api/generate`, {
        method: "POST",
        headers,
        body: JSON.stringify({
          model,
          prompt,
          stream: false,
        } satisfies OllamaRequest),
        signal: controller.signal,
      });

      clearTimeout(timeoutId);

      if (!response.ok) {
        const errorText = await response.text();
        throw new AiProviderError(`HTTP ${response.status}: ${errorText}`);
      }

      const data = await response.json() as OllamaResponse;
      return data;
    } catch (error) {
      clearTimeout(timeoutId);
      if (error instanceof Error && error.name === "AbortError") {
        throw new AiProviderError(`Request timeout after ${this.timeout}ms`);
      }
      throw error;
    }
  }
}

export const ollamaClient = new OllamaClient();
