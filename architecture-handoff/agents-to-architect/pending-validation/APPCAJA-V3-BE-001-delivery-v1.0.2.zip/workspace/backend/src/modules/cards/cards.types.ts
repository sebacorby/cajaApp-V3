export type CardStatementRowType =
  | "section_header"
  | "group_header"
  | "transaction"
  | "group_total"
  | "consolidated_row"
  | "tax"
  | "charge"
  | "statement_total"
  | "future_installment_reference"
  | "legal_text"
  | "unknown";

export type CurrencyOriginal = "ARS" | "USD" | "MIXED" | "UNKNOWN";

export interface CardStatementRow {
  id: string;
  displayOrder: number;
  sourcePage: number | null;

  sectionId: string;
  sectionLabel: string;

  groupId: string | null;
  groupLabel: string | null;
  groupOrder: number | null;

  rowType: CardStatementRowType;
  editable: boolean;

  dateRaw: string | null;
  dateIso: string | null;

  markerRaw: string | null;
  referenceRaw: string | null;
  installmentRaw: string | null;
  installmentCurrent: number | null;
  installmentTotal: number | null;

  receiptRaw: string | null;

  amountPesos: string | null;
  amountDollars: string | null;

  currencyOriginal: CurrencyOriginal;
  originalText: string;
  confidence: number | null;
  warnings: string[];
}

export interface CardStatementSection {
  id: string;
  displayOrder: number;
  label: string;
}

export interface CardStatementGroup {
  id: string;
  displayOrder: number;
  label: string;
  cardLast4: string | null;
  holderName: string | null;
}

export interface CardStatementPreview {
  statementId: string | null;
  source: {
    bankName: string | null;
    brand: string | null;
    statementNumber: string | null;
    pageCount: number;
  };
  summary: {
    totalPesos: string | null;
    totalDollars: string | null;
    minimumPaymentPesos: string | null;
    currentDueDate: string | null;
    nextClosingDate: string | null;
    nextDueDate: string | null;
  };
  sections: CardStatementSection[];
  groups: CardStatementGroup[];
  rows: CardStatementRow[];
  futureInstallmentsBlock: CardStatementRow[];
}

export interface ImportResult {
  draftId: string;
  document: {
    id: string;
    fileName: string;
    mimeType: string;
    sha256: string;
    pageCount: number;
  };
  status: string;
  warnings: string[];
  preview: CardStatementPreview;
}

export interface AcceptResult {
  statementId: string;
  status: string;
  updatedValues: {
    months: Array<{
      monthKey: string;
      label: string;
      totalPesos: string;
    }>;
    rows: unknown[];
  };
  warnings: string[];
}

export interface MonthlyProjection {
  monthKey: string;
  label: string;
  totalPesos: string;
  totalDollars: string;
}
