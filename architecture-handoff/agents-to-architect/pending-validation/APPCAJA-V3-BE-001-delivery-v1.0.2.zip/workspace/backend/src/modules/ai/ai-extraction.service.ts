import { ollamaClient } from "./ollama.client.js";
import { mockAiExtractionService } from "./mock-ai-extraction.service.js";
import { promptLoader } from "./prompt-loader.js";
import { jsonRepairService } from "./json-repair.service.js";
import { logger } from "../../shared/logger.js";
import { cardStatementPreviewSchema } from "../cards/cards.schemas.js";
import type { CardStatementPreview } from "../cards/cards.types.js";
import { validateData } from "../../shared/validation.js";
import { AiOutputSchemaInvalidError } from "../../shared/errors.js";
import { env } from "../../config/env.js";

export interface ExtractionResult {
  preview: CardStatementPreview;
  blockingErrors: string[];
  warnings: string[];
  retries: number;
}

export interface DocumentDetectionResult {
  documentType: string;
  confidence: number;
  reasoning: string;
}

export class AiExtractionService {
  async extractCardStatement(
    pdfText: string,
    pageCount: number,
    _aiRunId: string
  ): Promise<ExtractionResult> {
    if (env.AI_MOCK_MODE) {
      const mockResult = await mockAiExtractionService.extractCardStatementMock(pdfText, pageCount);
      return {
        preview: mockResult.preview,
        blockingErrors: mockResult.blockingErrors,
        warnings: mockResult.warnings,
        retries: 0,
      };
    }

    const promptTemplate = await promptLoader.loadExtractCardStatementPrompt();

    const instruction = promptTemplate.content
      .replace("{{PDF_TEXT}}", pdfText)
      .replace("{{PAGE_COUNT}}", String(pageCount));

    logger.info({
      promptHash: promptTemplate.hash.slice(0, 8),
      pageCount,
      textLength: pdfText.length,
    }, "Card statement extraction requested");

    const response = await ollamaClient.generate(instruction);

    const extractedJson = this.extractJson(response.response);

    if (!extractedJson) {
      throw new AiOutputSchemaInvalidError("Could not extract JSON from AI response");
    }

    const blockingErrors: string[] = [];
    const warnings: string[] = [];
    let preview: CardStatementPreview;

    try {
      preview = validateData(cardStatementPreviewSchema, extractedJson);
    } catch (error) {
      logger.warn({ error }, "Initial validation failed, attempting repair");

      const repairResult = await jsonRepairService.repairJson(
        JSON.stringify(extractedJson),
        cardStatementPreviewSchema
      );

      if (!repairResult.success) {
        throw new AiOutputSchemaInvalidError(repairResult.errors?.join("; ") || "Unknown validation error");
      }

      preview = repairResult.data as CardStatementPreview;
      warnings.push(...(repairResult.errors || []));
    }

    const validationResult = this.validateExtractedData(preview);
    blockingErrors.push(...validationResult.blockingErrors);
    warnings.push(...validationResult.warnings);

    logger.info({
      sectionsCount: preview.sections.length,
      groupsCount: preview.groups.length,
      rowsCount: preview.rows.length,
      blockingErrorsCount: blockingErrors.length,
      warningsCount: warnings.length,
    }, "Card statement extraction completed");

    return {
      preview,
      blockingErrors,
      warnings,
      retries: 0,
    };
  }

  async detectDocumentType(pdfText: string, pageCount: number): Promise<DocumentDetectionResult> {
    if (env.AI_MOCK_MODE) {
      return mockAiExtractionService.detectDocumentTypeMock();
    }

    const promptTemplate = await promptLoader.loadDetectDocumentPrompt();

    const instruction = promptTemplate.content
      .replace("{{PDF_TEXT}}", pdfText)
      .replace("{{PAGE_COUNT}}", String(pageCount));

    logger.info({
      promptHash: promptTemplate.hash.slice(0, 8),
      pageCount,
    }, "Document type detection requested (AI)");

    const response = await ollamaClient.generate(instruction);

    try {
      const result = JSON.parse(response.response);
      return {
        documentType: result.documentType || "unknown",
        confidence: result.confidence || 0,
        reasoning: result.reasoning || "",
      };
    } catch {
      return {
        documentType: "unknown",
        confidence: 0,
        reasoning: "Failed to parse AI response",
      };
    }
  }

  private extractJson(text: string): unknown | null {
    const jsonMatch = text.match(/```json\s*([\s\S]*?)\s*```/);
    if (jsonMatch) {
      try {
        return JSON.parse(jsonMatch[1]);
      } catch {
        // continue
      }
    }

    const braceMatch = text.match(/\{[\s\S]*\}/);
    if (braceMatch) {
      try {
        return JSON.parse(braceMatch[0]);
      } catch {
        // continue
      }
    }

    return null;
  }

  private validateExtractedData(preview: CardStatementPreview): { blockingErrors: string[]; warnings: string[] } {
    const blockingErrors: string[] = [];
    const warnings: string[] = [];

    if (!preview.summary?.totalPesos) {
      blockingErrors.push("Missing totalPesos in summary");
    }

    if (preview.rows.length === 0) {
      blockingErrors.push("No rows extracted from document");
    }

    const hasTransaction = preview.rows.some(r => r.rowType === "transaction");
    if (!hasTransaction) {
      blockingErrors.push("No transaction rows found");
    }

    const rowsWithoutOriginalText = preview.rows.filter(r => !r.originalText);
    if (rowsWithoutOriginalText.length > 0) {
      blockingErrors.push(`${rowsWithoutOriginalText.length} rows missing originalText`);
    }

    const displayOrders = preview.rows.map(r => r.displayOrder);
    const uniqueOrders = new Set(displayOrders);
    if (displayOrders.length !== uniqueOrders.size) {
      blockingErrors.push("Duplicate displayOrder values detected");
    }

    const sectionIds = new Set(preview.sections.map(s => s.id));
    for (const row of preview.rows) {
      if (row.sectionId && !sectionIds.has(row.sectionId)) {
        blockingErrors.push(`Row references unknown sectionId: ${row.sectionId}`);
      }
    }

    const groupIds = new Set(preview.groups.map(g => g.id));
    for (const row of preview.rows) {
      if (row.groupId && !groupIds.has(row.groupId)) {
        blockingErrors.push(`Row references unknown groupId: ${row.groupId}`);
      }
    }

    return { blockingErrors, warnings };
  }
}

export const aiExtractionService = new AiExtractionService();
