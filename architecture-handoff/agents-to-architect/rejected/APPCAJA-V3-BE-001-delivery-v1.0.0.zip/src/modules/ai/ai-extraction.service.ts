import { ollamaClient } from "./ollama.client.js";
import { promptLoader } from "./prompt-loader.js";
import { jsonRepairService } from "./json-repair.service.js";
import { logger } from "../../shared/logger.js";
import { cardStatementPreviewSchema } from "../cards/cards.schemas.js";
import type { CardStatementPreview } from "../cards/cards.types.js";
import { validateData } from "../../shared/validation.js";
import { AiOutputSchemaInvalidError } from "../../shared/errors.js";

export interface ExtractionResult {
  preview: CardStatementPreview;
  errors: string[];
  retries: number;
}

export class AiExtractionService {
  async extractCardStatement(
    pdfText: string,
    pageCount: number,
    _aiRunId: string
  ): Promise<ExtractionResult> {
    const promptTemplate = await promptLoader.loadExtractCardStatementPrompt();

    const instruction = promptTemplate.content
      .replace("{{PDF_TEXT}}", pdfText)
      .replace("{{PAGE_COUNT}}", String(pageCount));

    logger.info({
      promptHash: promptTemplate.hash.slice(0, 8),
      pageCount,
      textLength: pdfText.length,
    }, "Card statement extraction requested");

    const response = await ollamaClient.generate(instruction);

    const extractedJson = this.extractJson(response.response);

    if (!extractedJson) {
      throw new AiOutputSchemaInvalidError("Could not extract JSON from AI response");
    }

    const errors: string[] = [];
    let preview: CardStatementPreview;

    try {
      preview = validateData(cardStatementPreviewSchema, extractedJson);
    } catch (error) {
      logger.warn({ error }, "Initial validation failed, attempting repair");

      const repairResult = await jsonRepairService.repairJson(
        JSON.stringify(extractedJson),
        cardStatementPreviewSchema
      );

      if (!repairResult.success) {
        throw new AiOutputSchemaInvalidError(repairResult.errors?.join("; ") || "Unknown validation error");
      }

      preview = repairResult.data as CardStatementPreview;
      errors.push(...(repairResult.errors || []));
    }

    const validationErrors = this.validateExtractedData(preview);
    errors.push(...validationErrors);

    logger.info({
      sectionsCount: preview.sections.length,
      groupsCount: preview.groups.length,
      rowsCount: preview.rows.length,
      errorsCount: errors.length,
    }, "Card statement extraction completed");

    return {
      preview,
      errors,
      retries: 0,
    };
  }

  private extractJson(text: string): unknown | null {
    const jsonMatch = text.match(/```json\s*([\s\S]*?)\s*```/);
    if (jsonMatch) {
      try {
        return JSON.parse(jsonMatch[1]);
      } catch {
        // continue
      }
    }

    const braceMatch = text.match(/\{[\s\S]*\}/);
    if (braceMatch) {
      try {
        return JSON.parse(braceMatch[0]);
      } catch {
        // continue
      }
    }

    return null;
  }

  private validateExtractedData(preview: CardStatementPreview): string[] {
    const errors: string[] = [];

    if (!preview.summary?.totalPesos) {
      errors.push("Missing totalPesos in summary");
    }

    if (preview.rows.length === 0) {
      errors.push("No rows extracted from document");
    }

    const hasTransaction = preview.rows.some(r => r.rowType === "transaction");
    if (!hasTransaction) {
      errors.push("No transaction rows found");
    }

    const rowsWithoutOriginalText = preview.rows.filter(r => !r.originalText);
    if (rowsWithoutOriginalText.length > 0) {
      errors.push(`${rowsWithoutOriginalText.length} rows missing originalText`);
    }

    const displayOrders = preview.rows.map(r => r.displayOrder);
    const uniqueOrders = new Set(displayOrders);
    if (displayOrders.length !== uniqueOrders.size) {
      errors.push("Duplicate displayOrder values detected");
    }

    return errors;
  }
}

export const aiExtractionService = new AiExtractionService();
