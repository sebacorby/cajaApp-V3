import { prisma } from "../../db/prisma.js";
import { NotFoundError } from "../../shared/errors.js";
import type { CardStatementPreview, AcceptResult, MonthlyProjection } from "./cards.types.js";
import { logger } from "../../shared/logger.js";

export class CardsService {
  async getDraft(draftId: string) {
    const draft = await prisma.cardStatementDraft.findUnique({
      where: { id: draftId },
      include: {
        document: true,
        aiRun: true,
        sections: {
          orderBy: { displayOrder: "asc" },
        },
        groups: {
          orderBy: { displayOrder: "asc" },
        },
        rows: {
          orderBy: { displayOrder: "asc" },
        },
      },
    });

    if (!draft) {
      throw new NotFoundError("Draft");
    }

    return draft;
  }

  async getStatement(statementId: string) {
    const statement = await prisma.cardStatement.findUnique({
      where: { id: statementId },
      include: {
        sections: { orderBy: { displayOrder: "asc" } },
        groups: { orderBy: { displayOrder: "asc" } },
        rows: { orderBy: { displayOrder: "asc" } },
        projections: { orderBy: { monthKey: "asc" } },
        manualPurchases: true,
      },
    });

    if (!statement) {
      throw new NotFoundError("Statement");
    }

    return statement;
  }

  async acceptDraft(draftId: string, preview: CardStatementPreview): Promise<AcceptResult> {
    const draft = await this.getDraft(draftId);

    if (draft.status !== "preview_ready") {
      throw new Error(`Cannot accept draft in status: ${draft.status}`);
    }

    const groupSectionMap = new Map<string, string>();
    for (const row of preview.rows) {
      if (row.groupId && row.sectionId && !groupSectionMap.has(row.groupId)) {
        groupSectionMap.set(row.groupId, row.sectionId);
      }
    }

    const statement = await prisma.cardStatement.create({
      data: {
        documentId: draft.documentId,
        draftId: draft.id,
        bankName: preview.source.bankName,
        brand: preview.source.brand,
        statementNumber: preview.source.statementNumber,
        periodLabel: preview.summary.currentDueDate || null,
        totalPesosRaw: preview.summary.totalPesos,
        totalDollarsRaw: preview.summary.totalDollars,
        minimumPaymentPesosRaw: preview.summary.minimumPaymentPesos,
        currentDueDate: preview.summary.currentDueDate,
        nextClosingDate: preview.summary.nextClosingDate,
        nextDueDate: preview.summary.nextDueDate,
        status: "accepted",
        sections: {
          create: preview.sections.map(s => ({
            sectionId: s.id,
            label: s.label,
            displayOrder: s.displayOrder,
          })),
        },
        groups: {
          create: preview.groups.map(g => ({
            groupId: g.id,
            label: g.label,
            displayOrder: g.displayOrder,
            cardLast4: g.cardLast4,
            holderName: g.holderName,
            sectionId: groupSectionMap.get(g.id) || preview.sections[0]?.id || "",
          })),
        },
        rows: {
          create: preview.rows.map(r => ({
            sectionId: r.sectionId,
            groupId: r.groupId,
            displayOrder: r.displayOrder,
            sourcePage: r.sourcePage,
            rowType: r.rowType,
            editable: r.editable,
            dateRaw: r.dateRaw,
            dateIso: r.dateIso,
            markerRaw: r.markerRaw,
            referenceRaw: r.referenceRaw,
            installmentRaw: r.installmentRaw,
            receiptRaw: r.receiptRaw,
            amountPesosRaw: r.amountPesos,
            amountDollarsRaw: r.amountDollars,
            currencyOriginal: r.currencyOriginal,
            originalText: r.originalText,
            confidence: r.confidence,
          })),
        },
      },
      include: {
        projections: { orderBy: { monthKey: "asc" } },
        rows: true,
        groups: true,
      },
    });

    await prisma.cardStatementDraft.update({
      where: { id: draftId },
      data: { status: "accepted" },
    });

    const monthMap = new Map<string, MonthlyProjection>();

    for (const projection of statement.projections) {
      if (!monthMap.has(projection.monthKey)) {
        monthMap.set(projection.monthKey, {
          monthKey: projection.monthKey,
          label: projection.label,
          totalPesos: "0",
        });
      }
      const existing = monthMap.get(projection.monthKey)!;
      const current = parseFloat(existing.totalPesos.replace(/\./g, "").replace(",", "."));
      const add = parseFloat(projection.amountPesosRaw?.replace(/\./g, "").replace(",", ".") || "0");
      existing.totalPesos = (current + add).toLocaleString("es-AR", {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2,
      });
    }

    const months = Array.from(monthMap.values()).sort((a, b) => a.monthKey.localeCompare(b.monthKey));

    return {
      statementId: statement.id,
      status: "accepted",
      updatedValues: {
        months,
        rows: statement.rows,
      },
      warnings: [],
    };
  }

  async getUpdatedValues(fromMonth: string, toMonth: string): Promise<{ months: MonthlyProjection[] }> {
    const statements = await prisma.cardStatement.findMany({
      where: {
        status: "accepted",
      },
      include: {
        projections: {
          where: {
            monthKey: {
              gte: fromMonth,
              lte: toMonth,
            },
          },
          orderBy: { monthKey: "asc" },
        },
        manualPurchases: true,
      },
    });

    const monthMap = new Map<string, MonthlyProjection>();

    for (const stmt of statements) {
      for (const projection of stmt.projections) {
        if (!monthMap.has(projection.monthKey)) {
          monthMap.set(projection.monthKey, {
            monthKey: projection.monthKey,
            label: projection.label,
            totalPesos: "0.00",
          });
        }
        const existing = monthMap.get(projection.monthKey)!;
        const current = parseFloat(existing.totalPesos.replace(/\./g, "").replace(",", "."));
        const add = parseFloat(projection.amountPesosRaw?.replace(/\./g, "").replace(",", ".") || "0");
        existing.totalPesos = (current + add).toLocaleString("es-AR", {
          minimumFractionDigits: 2,
          maximumFractionDigits: 2,
        });
      }
    }

    const months = Array.from(monthMap.values()).sort((a, b) => a.monthKey.localeCompare(b.monthKey));

    logger.info({ fromMonth, toMonth, monthsCount: months.length }, "Updated values retrieved");

    return { months };
  }
}

export const cardsService = new CardsService();
