# APPCAJA-V3-BE-001 Delivery Report

## Estado
PASS (v1.0.0)

## Resumen técnico

Backend completo para importación de resúmenes de tarjeta PDF con IA via Ollama, persistencia Prisma/SQLite, y cálculo de cuotas futuras.

### Stack implementado
- Node.js 22.x
- TypeScript
- Fastify
- Prisma con SQLite local
- Zod para validación
- pdf.js-dist para extracción de texto PDF
- Ollama API para IA (con modo mock)

### Endpoints implementados

| Método | Ruta | Descripción |
|--------|------|-------------|
| GET | /health | Healthcheck del servicio |
| POST | /api/card-statements/import | Importar PDF de resumen |
| GET | /api/card-statements/drafts/:draftId | Obtener draft |
| POST | /api/card-statements/drafts/:draftId/accept | Aceptar y persistir |
| GET | /api/card-statements/updated-values | Valores actualizados por mes |
| POST | /api/cards/manual-purchases | Compra manual |

### Archivos creados

**Backend (workspace/backend/):**
- package.json, tsconfig.json, .env.example, vitest.config.ts
- src/main.ts, src/app.ts
- src/config/env.ts
- src/db/prisma.ts
- src/shared/logger.ts, errors.ts, money.ts, dates.ts, validation.ts
- src/modules/health/health.routes.ts
- src/modules/cards/cards.routes.ts, cards.controller.ts, cards.service.ts, cards.schemas.ts, cards.types.ts
- src/modules/imports/imports.routes.ts, imports.controller.ts, imports.service.ts, document-detector.service.ts, pdf-text-extractor.service.ts
- src/modules/ai/ollama.client.ts, prompt-loader.ts, ai-extraction.service.ts, json-repair.service.ts
- src/modules/projections/installment-projection.service.ts
- src/modules/manual-purchases/manual-purchases.routes.ts, manual-purchases.controller.ts, manual-purchases.service.ts
- prisma/schema.prisma

**Contratos (contracts/):**
- contracts/prompts/cards/00-detect-document-type.md
- contracts/prompts/cards/01-extract-credit-card-statement.md
- contracts/prompts/cards/02-repair-credit-card-json.md
- contracts/schemas/cards/card-statement-import.schema.json
- contracts/schemas/cards/card-statement-preview.schema.json
- contracts/schemas/cards/card-statement-accepted.schema.json
- contracts/examples/cards/visa-galicia-julio2026.sanitized.preview.json
- contracts/examples/cards/visa-galicia-julio2026.sanitized.accepted.json

**Tests:**
- tests/cards/card-statement.schema.test.ts
- tests/cards/installment-projection.service.test.ts
- tests/imports/pdf-import-contract.test.ts
- tests/imports/display-order-preservation.test.ts

### Decisiones técnicas

1. **Modo mock**: AI_MOCK_MODE=true por defecto para permitir desarrollo sin Ollama Cloud
2. **Schema Prisma**: 10 modelos incluyendo UploadedDocument, AiExtractionRun, CardStatementDraft, CardStatement, proyecciones
3. **Dinero**: Uso de BigInt para cálculos monetarios en centavos, strings para API
4. **Proyecciones**: Cálculo de cuotas futuras solo en backend, no convierte USD a ARS

### Comandos ejecutados

- `node -v`: v22.14.0
- `npm install`: SUCCESS
- `npx prisma generate`: SUCCESS
- `npm run build`: SUCCESS
- `npm run test`: SUCCESS (38 tests)

### Configuración .env

```env
NODE_ENV=development
PORT=4000
HOST=127.0.0.1
DATABASE_URL="file:./dev.db"
STORAGE_DIR="./storage"
MAX_UPLOAD_BYTES=10485760
OLLAMA_BASE_URL="https://ollama.com"
OLLAMA_API_KEY=""
OLLAMA_MODEL=""
OLLAMA_TIMEOUT_MS=120000
OLLAMA_MAX_RETRIES=2
CARD_STATEMENT_PROMPTS_DIR="../../contracts/prompts/cards"
AI_MOCK_MODE=true
```

### Cómo correr

```bash
cd workspace/backend
npm install
npx prisma generate
npx prisma migrate dev
npm run dev
```

### Known issues

1. Error preexistente de hidratación en frontend MonthlyEvolutionChart (no introducido por esta entrega)
2. El post-build script usa `cp` (Unix) que no funciona en Windows - el build compila correctamente

### Confirmaciones

- Frontend no fue modificado
- No se copiaron artifacts de CajaApp V2
- PDF real no fue commiteado
- .env no fue commiteado (solo .env.example)
