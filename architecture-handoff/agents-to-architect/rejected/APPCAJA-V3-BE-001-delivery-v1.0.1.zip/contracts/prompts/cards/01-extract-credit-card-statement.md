# Credit Card Statement Extraction Prompt

You are an expert at extracting structured data from credit card PDF statements.

## Task

Extract all information from the provided credit card statement PDF text and return it as a structured JSON object.

## Critical Rules

1. **PRESERVE ORDER**: Do NOT sort rows by date, amount, card, or any other criteria. Keep the exact order as it appears in the document.
2. **DO NOT CALCULATE**: Do not calculate new totals, do not sum amounts, do not compute differences.
3. **DO NOT CONVERT**: Do not convert USD to ARS or vice versa. Keep amounts in their original currency.
4. **DO NOT INFER**: If data is not present in the document, use `null`. Do not make up information.
5. **PRESERVE ORIGINAL TEXT**: Always keep the `originalText` field with the exact text from the document.
6. **ASSIGN displayOrder**: Assign sequential `displayOrder` numbers (1, 2, 3...) to each row based on document order.
7. **USE STRING DECIMALS**: All amounts must be strings in format "123456.78" (two decimal places for pesos, two for dollars).

## Document Analysis

The PDF text below contains {{PAGE_COUNT}} pages marked with "--- PAGE X / Y ---" markers.

## PDF Text

{{PDF_TEXT}}

## Required Output Schema

```json
{
  "statementId": null,
  "source": {
    "bankName": "string | null",
    "brand": "string | null",
    "statementNumber": "string | null",
    "pageCount": "number"
  },
  "summary": {
    "totalPesos": "string | null",
    "totalDollars": "string | null",
    "minimumPaymentPesos": "string | null",
    "currentDueDate": "string | null",
    "nextClosingDate": "string | null",
    "nextDueDate": "string | null"
  },
  "sections": [
    {
      "id": "string",
      "displayOrder": "number",
      "label": "string"
    }
  ],
  "groups": [
    {
      "id": "string",
      "displayOrder": "number",
      "label": "string",
      "cardLast4": "string | null",
      "holderName": "string | null"
    }
  ],
  "rows": [
    {
      "id": "string",
      "displayOrder": "number",
      "sourcePage": "number | null",
      "sectionId": "string",
      "sectionLabel": "string",
      "groupId": "string | null",
      "groupLabel": "string | null",
      "groupOrder": "number | null",
      "rowType": "section_header | group_header | transaction | group_total | consolidated_row | tax | charge | statement_total | future_installment_reference | legal_text | unknown",
      "editable": "boolean",
      "dateRaw": "string | null",
      "dateIso": "string | null (format: YYYY-MM-DD)",
      "markerRaw": "string | null (* or K or null)",
      "referenceRaw": "string | null",
      "installmentRaw": "string | null (format: X/Y)",
      "installmentCurrent": "number | null",
      "installmentTotal": "number | null",
      "receiptRaw": "string | null",
      "amountPesos": "string | null",
      "amountDollars": "string | null",
      "currencyOriginal": "ARS | USD | MIXED | UNKNOWN",
      "originalText": "string",
      "confidence": "number | null (0-1)",
      "warnings": []
    }
  ],
  "futureInstallmentsBlock": []
}
```

## Row Type Definitions

- `section_header`: Marks the beginning of a section
- `group_header`: Marks the beginning of a card/titular group
- `transaction`: Individual purchase/consumption
- `group_total`: Subtotal for a card group
- `consolidated_row`: Row in consolidated summary
- `tax`: Tax or fee charge
- `charge`: Other charge type
- `statement_total`: Final total for the statement
- `future_installment_reference`: Reference to future installments
- `legal_text`: Legal disclaimer or information text

## Editable Rules

- `transaction`, `tax`, `charge` rows: editable = true
- `group_total`, `statement_total`, `section_header`, `legal_text`: editable = false

## Important Notes

- Use `displayOrder` to track the original document order - this is critical for audit compliance
- `groupId` should match between transaction rows and their group_header
- `sectionId` should match between rows and their section
- Parse installment strings like "1/3" into `installmentCurrent: 1` and `installmentTotal: 3`
- Keep amounts as strings, do not convert to numbers
- For dates, provide both `dateRaw` (original format) and `dateIso` (YYYY-MM-DD)
- Mark suspicious extractions with a warning in the `warnings` array
