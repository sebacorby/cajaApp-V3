import { buildApp } from "./app.js";
import { connectDatabase, disconnectDatabase } from "./db/prisma.js";
import { env } from "./config/env.js";
import { logger } from "./shared/logger.js";

async function main() {
  try {
    await connectDatabase();

    const app = await buildApp();

    await app.listen({
      port: env.PORT,
      host: env.HOST,
    });

    logger.info(`Server running on http://${env.HOST}:${env.PORT}`);

    const shutdown = async (signal: string) => {
      logger.info({ signal }, "Shutdown signal received");
      await app.close();
      await disconnectDatabase();
      process.exit(0);
    };

    process.on("SIGTERM", () => shutdown("SIGTERM"));
    process.on("SIGINT", () => shutdown("SIGINT"));
  } catch (error) {
    logger.error({ error }, "Failed to start server");
    process.exit(1);
  }
}

main();
