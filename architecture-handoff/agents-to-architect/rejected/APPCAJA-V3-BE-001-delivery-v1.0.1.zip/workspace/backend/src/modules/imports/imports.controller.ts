import { FastifyInstance, FastifyPluginAsync } from "fastify";
import { importsService } from "./imports.service.js";
import { logger } from "../../shared/logger.js";

export const importsController: FastifyPluginAsync = async (app: FastifyInstance) => {
  app.post("/import", async (request, reply) => {
    const data = await request.file();

    if (!data) {
      return reply.status(400).send({ code: "FILE_REQUIRED", message: "No file provided" });
    }

    const fileBuffer = await data.toBuffer();

    const fileData = {
      filename: data.filename,
      mimetype: data.mimetype,
      file: fileBuffer,
    };

    logger.info({ filename: fileData.filename, size: fileData.file.length }, "Import request received");

    const result = await importsService.importPdf(fileData);

    return reply.send(result);
  });
};
