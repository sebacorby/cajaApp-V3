import fs from "fs/promises";
import path from "path";
import crypto from "crypto";
import { prisma } from "../../db/prisma.js";
import { pdfTextExtractorService } from "./pdf-text-extractor.service.js";
import { documentDetectorService, DocumentType } from "./document-detector.service.js";
import { aiExtractionService } from "../ai/ai-extraction.service.js";
import { env } from "../../config/env.js";
import { logger } from "../../shared/logger.js";
import {
  FileRequiredError,
  FileTooLargeError,
  UnsupportedMediaTypeError,
  UnsupportedDocumentTypeError,
} from "../../shared/errors.js";
import type { ImportResult } from "../cards/cards.types.js";

export class ImportsService {
  async importPdf(file: { filename: string; mimetype: string; file: Buffer }): Promise<ImportResult> {
    if (!file || !file.file || file.file.length === 0) {
      throw new FileRequiredError();
    }

    if (file.file.length > env.MAX_UPLOAD_BYTES) {
      throw new FileTooLargeError(env.MAX_UPLOAD_BYTES);
    }

    if (file.mimetype !== "application/pdf") {
      throw new UnsupportedMediaTypeError(file.mimetype);
    }

    const storageDir = path.resolve(env.STORAGE_DIR);
    await fs.mkdir(storageDir, { recursive: true });

    const fileBuffer = Buffer.isBuffer(file.file) ? file.file : Buffer.from(file.file);
    const sha256 = crypto.createHash("sha256").update(fileBuffer).digest("hex");
    const storedFilename = `${sha256}_${file.filename}`;
    const storagePath = path.join(storageDir, storedFilename);

    await fs.writeFile(storagePath, fileBuffer);

    const pdfExtraction = await pdfTextExtractorService.extractFromBuffer(fileBuffer);

    const detectedType = documentDetectorService.detectMimeType(file.filename, file.mimetype);

    if (detectedType === "csv") {
      throw new UnsupportedDocumentTypeError("csv");
    }
    if (detectedType === "png") {
      throw new UnsupportedDocumentTypeError("png");
    }
    if (detectedType === "jpg") {
      throw new UnsupportedDocumentTypeError("jpg");
    }

    const documentType = documentDetectorService.detectDocumentType(pdfExtraction.fullTextWithPageMarkers);

    if (documentType !== "credit_card_statement_pdf") {
      throw new UnsupportedDocumentTypeError(documentType);
    }

    const document = await prisma.uploadedDocument.create({
      data: {
        fileName: file.filename,
        mimeType: file.mimetype,
        sizeBytes: fileBuffer.length,
        sha256,
        storagePath,
        pageCount: pdfExtraction.pageCount,
      },
    });

    const aiRun = await prisma.aiExtractionRun.create({
      data: {
        documentId: document.id,
        promptFilePath: `${env.CARD_STATEMENT_PROMPTS_DIR}/01-extract-credit-card-statement.md`,
        promptHash: "pending",
        modelProvider: "ollama",
        modelBaseUrl: env.OLLAMA_BASE_URL,
        modelName: env.OLLAMA_MODEL || "mock",
        status: "started",
      },
    });

    const extractionResult = await aiExtractionService.extractCardStatement(
      pdfExtraction.fullTextWithPageMarkers,
      pdfExtraction.pageCount,
      aiRun.id
    );

    await prisma.aiExtractionRun.update({
      where: { id: aiRun.id },
      data: {
        jsonOutput: JSON.stringify(extractionResult.preview),
        validationErrors: extractionResult.errors.length > 0 ? JSON.stringify(extractionResult.errors) : null,
        retries: extractionResult.retries,
        status: extractionResult.errors.length > 0 ? "failed" : "completed",
        completedAt: new Date(),
      },
    });

    const groupSectionMap = new Map<string, string>();
    for (const row of extractionResult.preview.rows) {
      if (row.groupId && row.sectionId && !groupSectionMap.has(row.groupId)) {
        groupSectionMap.set(row.groupId, row.sectionId);
      }
    }

    const draft = await prisma.cardStatementDraft.create({
      data: {
        documentId: document.id,
        aiRunId: aiRun.id,
        status: "preview_ready",
        previewJson: JSON.stringify(extractionResult.preview),
        sections: {
          create: extractionResult.preview.sections.map(s => ({
            sectionKey: s.id,
            label: s.label,
            displayOrder: s.displayOrder,
          })),
        },
        groups: {
          create: extractionResult.preview.groups.map(g => ({
            groupKey: g.id,
            sectionKey: groupSectionMap.get(g.id) || extractionResult.preview.sections[0]?.id || "",
            label: g.label,
            displayOrder: g.displayOrder,
            cardLast4: g.cardLast4,
            holderName: g.holderName,
          })),
        },
        rows: {
          create: extractionResult.preview.rows.map(r => ({
            sectionKey: r.sectionId,
            groupKey: r.groupId,
            displayOrder: r.displayOrder,
            sourcePage: r.sourcePage,
            rowType: r.rowType,
            editable: r.editable,
            dateRaw: r.dateRaw,
            dateIso: r.dateIso,
            markerRaw: r.markerRaw,
            referenceRaw: r.referenceRaw,
            installmentRaw: r.installmentRaw,
            receiptRaw: r.receiptRaw,
            amountPesosRaw: r.amountPesos,
            amountDollarsRaw: r.amountDollars,
            currencyOriginal: r.currencyOriginal,
            originalText: r.originalText,
            confidence: r.confidence,
          })),
        },
      },
    });

    logger.info({ draftId: draft.id, documentId: document.id }, "Card statement draft created");

    return {
      draftId: draft.id,
      document: {
        id: document.id,
        fileName: document.fileName,
        mimeType: document.mimeType,
        sha256: document.sha256,
        pageCount: document.pageCount!,
      },
      status: "preview_ready",
      warnings: extractionResult.errors,
      preview: extractionResult.preview,
    };
  }
}

export const importsService = new ImportsService();
