import fs from "fs/promises";
import path from "path";
import { logger } from "../../shared/logger.js";
import { ScannedPdfNotSupportedError } from "../../shared/errors.js";

export interface PdfPage {
  pageNumber: number;
  text: string;
  items?: Array<{
    text: string;
    x?: number;
    y?: number;
    width?: number;
    height?: number;
  }>;
}

export interface ExtractedPdfText {
  pageCount: number;
  pages: PdfPage[];
  fullTextWithPageMarkers: string;
}

export class PdfTextExtractorService {
  private pdfJs: typeof import("pdfjs-dist") | null = null;

  private async loadPdfJs() {
    if (!this.pdfJs) {
      this.pdfJs = await import("pdfjs-dist");
    }
    return this.pdfJs;
  }

  async extractText(pdfPath: string): Promise<ExtractedPdfText> {
    const pdfjs = await this.loadPdfJs();

    const data = await fs.readFile(pdfPath);
    const pdf = await pdfjs.getDocument({ data }).promise;

    const pageCount = pdf.numPages;
    const pages: PdfPage[] = [];
    const pageTexts: string[] = [];

    for (let i = 1; i <= pageCount; i++) {
      const page = await pdf.getPage(i);
      const content = await page.getTextContent();

      if (!content.items || content.items.length === 0) {
        throw new ScannedPdfNotSupportedError();
      }

      const text = content.items
        .map((item: any) => item.str)
        .join(" ")
        .replace(/\s+/g, " ")
        .trim();

      if (text.length < 10) {
        throw new ScannedPdfNotSupportedError();
      }

      pages.push({
        pageNumber: i,
        text,
        items: content.items.map((item: any) => ({
          text: item.str,
          x: item.transform?.[4],
          y: item.transform?.[5],
          width: item.width,
          height: item.height,
        })),
      });

      pageTexts.push(`--- PAGE ${i} / ${pageCount} ---\n${text}`);
    }

    const fullTextWithPageMarkers = pageTexts.join("\n\n");

    logger.info({ pdfPath, pageCount }, "PDF text extracted successfully");

    return {
      pageCount,
      pages,
      fullTextWithPageMarkers,
    };
  }

  async extractFromBuffer(buffer: Buffer): Promise<ExtractedPdfText> {
    const pdfjs = await this.loadPdfJs();

    const pdf = await pdfjs.getDocument({ data: buffer }).promise;

    const pageCount = pdf.numPages;
    const pages: PdfPage[] = [];
    const pageTexts: string[] = [];

    for (let i = 1; i <= pageCount; i++) {
      const page = await pdf.getPage(i);
      const content = await page.getTextContent();

      if (!content.items || content.items.length === 0) {
        throw new ScannedPdfNotSupportedError();
      }

      const text = content.items
        .map((item: any) => item.str)
        .join(" ")
        .replace(/\s+/g, " ")
        .trim();

      if (text.length < 10) {
        throw new ScannedPdfNotSupportedError();
      }

      pages.push({
        pageNumber: i,
        text,
        items: content.items.map((item: any) => ({
          text: item.str,
          x: item.transform?.[4],
          y: item.transform?.[5],
          width: item.width,
          height: item.height,
        })),
      });

      pageTexts.push(`--- PAGE ${i} / ${pageCount} ---\n${text}`);
    }

    const fullTextWithPageMarkers = pageTexts.join("\n\n");

    logger.info({ pageCount }, "PDF text extracted from buffer");

    return {
      pageCount,
      pages,
      fullTextWithPageMarkers,
    };
  }
}

export const pdfTextExtractorService = new PdfTextExtractorService();
