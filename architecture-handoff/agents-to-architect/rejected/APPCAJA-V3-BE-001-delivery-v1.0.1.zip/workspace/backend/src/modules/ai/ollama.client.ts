import { env } from "../../config/env.js";
import { logger, sanitizeForLog } from "../../shared/logger.js";
import { AiProviderError } from "../../shared/errors.js";
import crypto from "crypto";

export interface OllamaRequest {
  model: string;
  prompt: string;
  stream: boolean;
}

export interface OllamaResponse {
  model: string;
  response: string;
  done: boolean;
  context?: number[];
  total_duration?: number;
  load_duration?: number;
  prompt_eval_count?: number;
  prompt_eval_duration?: number;
  eval_count?: number;
  eval_duration?: number;
}

export class OllamaClient {
  private apiKey: string;
  private baseUrl: string;
  private timeout: number;
  private maxRetries: number;

  constructor() {
    this.apiKey = env.OLLAMA_API_KEY;
    this.baseUrl = env.OLLAMA_BASE_URL;
    this.timeout = env.OLLAMA_TIMEOUT_MS;
    this.maxRetries = env.OLLAMA_MAX_RETRIES;
  }

  async generate(prompt: string, model?: string): Promise<OllamaResponse> {
    if (env.AI_MOCK_MODE) {
      return this.mockResponse(prompt);
    }

    const targetModel = model || env.OLLAMA_MODEL;
    if (!targetModel) {
      throw new AiProviderError("OLLAMA_MODEL not configured and AI_MOCK_MODE is false");
    }

    const startTime = Date.now();
    let lastError: Error | null = null;
    let attempts = 0;

    for (attempts = 0; attempts <= this.maxRetries; attempts++) {
      try {
        const response = await this.doRequest(prompt, targetModel);
        const duration = Date.now() - startTime;

        logger.info({
          model: targetModel,
          duration,
          status: "success",
          promptHash: crypto.createHash("sha256").update(prompt).digest("hex").slice(0, 8),
          responseHash: crypto.createHash("sha256").update(response.response).digest("hex").slice(0, 8),
          retries: attempts,
        }, "Ollama request completed");

        return response;
      } catch (error) {
        lastError = error instanceof Error ? error : new Error(String(error));
        logger.warn({ attempt: attempts + 1, maxRetries: this.maxRetries, error: lastError.message }, "Ollama request failed, retrying...");
      }
    }

    logger.error({
      model: targetModel,
      attempts,
      error: lastError?.message,
    }, "Ollama request failed after all retries");

    throw new AiProviderError(`Ollama request failed after ${attempts} attempts: ${lastError?.message}`);
  }

  private async doRequest(prompt: string, model: string): Promise<OllamaResponse> {
    const headers: Record<string, string> = {
      "Content-Type": "application/json",
    };

    if (this.apiKey) {
      headers["Authorization"] = `Bearer ${this.apiKey}`;
    }

    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), this.timeout);

    try {
      const response = await fetch(`${this.baseUrl}/api/generate`, {
        method: "POST",
        headers,
        body: JSON.stringify({
          model,
          prompt,
          stream: false,
        } satisfies OllamaRequest),
        signal: controller.signal,
      });

      clearTimeout(timeoutId);

      if (!response.ok) {
        const errorText = await response.text();
        throw new AiProviderError(`HTTP ${response.status}: ${errorText}`);
      }

      const data = await response.json() as OllamaResponse;
      return data;
    } catch (error) {
      clearTimeout(timeoutId);
      if (error instanceof Error && error.name === "AbortError") {
        throw new AiProviderError(`Request timeout after ${this.timeout}ms`);
      }
      throw error;
    }
  }

  private mockResponse(prompt: string): OllamaResponse {
    logger.info({ message: "Using AI MOCK MODE" }, "Mock response generated");

    const mockPreview = {
      statementId: null,
      source: {
        bankName: "Banco Galicia",
        brand: "VISA",
        statementNumber: "VI00000000000839532",
        pageCount: 8,
      },
      summary: {
        totalPesos: "3118842.50",
        totalDollars: "161.84",
        minimumPaymentPesos: "508000.00",
        currentDueDate: "2026-07-13",
        nextClosingDate: "2026-07-30",
        nextDueDate: "2026-08-07",
      },
      sections: [
        { id: "consolidated", displayOrder: 1, label: "Consolidado" },
        { id: "charges", displayOrder: 2, label: "Cargos e Impuestos" },
        { id: "plan-v", displayOrder: 3, label: "Plan V" },
        { id: "future-installments", displayOrder: 4, label: "Cuotas a Vencer" },
      ],
      groups: [
        { id: "g-6792", displayOrder: 1, label: "TARJETA 6792 Total Consumos de JAVIER SEB CORBELLA", cardLast4: "6792", holderName: "JAVIER SEB CORBELLA" },
        { id: "g-5884", displayOrder: 2, label: "TARJETA 5884 Total Consumos de EMILSE RITA JIMENEZ", cardLast4: "5884", holderName: "EMILSE RITA JIMENEZ" },
        { id: "g-4255", displayOrder: 3, label: "TARJETA 4255 Total Consumos de JAVIER SEB CORBELLA", cardLast4: "4255", holderName: "JAVIER SEB CORBELLA" },
        { id: "g-0015", displayOrder: 4, label: "TARJETA 0015 Total Consumos de LUCAS SALVA JIMENEZ", cardLast4: "0015", holderName: "LUCAS SALVA JIMENEZ" },
      ],
      rows: [
        { id: "r-6792-1", displayOrder: 1, sourcePage: 2, sectionId: "consolidated", sectionLabel: "Consolidado", groupId: "g-6792", groupLabel: "TARJETA 6792", groupOrder: 1, rowType: "transaction", editable: true, dateRaw: "15-Jun-26", dateIso: "2026-06-15", markerRaw: null, referenceRaw: "AMAZON.COM", installmentRaw: "1/3", installmentCurrent: 1, installmentTotal: 3, receiptRaw: "012345", amountPesos: "45678.90", amountDollars: null, currencyOriginal: "ARS", originalText: "AMAZON.COM 1/3 45678.90", confidence: 0.95, warnings: [] },
        { id: "r-6792-2", displayOrder: 2, sourcePage: 2, sectionId: "consolidated", sectionLabel: "Consolidado", groupId: "g-6792", groupLabel: "TARJETA 6792", groupOrder: 1, rowType: "transaction", editable: true, dateRaw: "18-Jun-26", dateIso: "2026-06-18", markerRaw: null, referenceRaw: "UBER TRIP", installmentRaw: "1/1", installmentCurrent: 1, installmentTotal: 1, receiptRaw: "012346", amountPesos: "8234.50", amountDollars: null, currencyOriginal: "ARS", originalText: "UBER TRIP 1/1 8234.50", confidence: 0.95, warnings: [] },
        { id: "r-6792-3", displayOrder: 3, sourcePage: 3, sectionId: "consolidated", sectionLabel: "Consolidado", groupId: "g-6792", groupLabel: "TARJETA 6792", groupOrder: 1, rowType: "transaction", editable: true, dateRaw: "22-Jun-26", dateIso: "2026-06-22", markerRaw: null, referenceRaw: "BOOKING.COM", installmentRaw: "2/4", installmentCurrent: 2, installmentTotal: 4, receiptRaw: "012347", amountPesos: "156789.00", amountDollars: "150.00", currencyOriginal: "MIXED", originalText: "BOOKING.COM 2/4 156789.00 USD 150.00", confidence: 0.9, warnings: [] },
        { id: "r-6792-4", displayOrder: 4, sourcePage: 3, sectionId: "consolidated", sectionLabel: "Consolidado", groupId: "g-6792", groupLabel: "TARJETA 6792", groupOrder: 1, rowType: "transaction", editable: true, dateRaw: "25-Jun-26", dateIso: "2026-06-25", markerRaw: null, referenceRaw: "NETFLIX.COM", installmentRaw: "1/1", installmentCurrent: 1, installmentTotal: 1, receiptRaw: "012348", amountPesos: "8303.49", amountDollars: "11.84", currencyOriginal: "MIXED", originalText: "NETFLIX.COM 1/1 8303.49 USD 11.84", confidence: 0.95, warnings: [] },
        { id: "r-6792-t", displayOrder: 5, sourcePage: 3, sectionId: "consolidated", sectionLabel: "Consolidado", groupId: "g-6792", groupLabel: "TARJETA 6792", groupOrder: 1, rowType: "group_total", editable: false, dateRaw: null, dateIso: null, markerRaw: null, referenceRaw: "Total TARJETA 6792", installmentRaw: null, installmentCurrent: null, installmentTotal: null, receiptRaw: null, amountPesos: "1850347.50", amountDollars: "161.84", currencyOriginal: "MIXED", originalText: "Total TARJETA 6792", confidence: null, warnings: [] },
      ],
      futureInstallmentsBlock: [],
    };

    return {
      model: "mock",
      response: JSON.stringify(mockPreview),
      done: true,
    };
  }
}

export const ollamaClient = new OllamaClient();
