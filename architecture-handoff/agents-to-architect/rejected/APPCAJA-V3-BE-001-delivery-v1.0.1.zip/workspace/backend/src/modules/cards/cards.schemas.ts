import { z } from "zod";

export const cardStatementRowTypeSchema = z.enum([
  "section_header",
  "group_header",
  "transaction",
  "group_total",
  "consolidated_row",
  "tax",
  "charge",
  "statement_total",
  "future_installment_reference",
  "legal_text",
  "unknown",
]);

export const currencyOriginalSchema = z.enum(["ARS", "USD", "MIXED", "UNKNOWN"]);

export const cardStatementRowSchema = z.object({
  id: z.string(),
  displayOrder: z.number(),
  sourcePage: z.number().nullable(),
  sectionId: z.string(),
  sectionLabel: z.string(),
  groupId: z.string().nullable(),
  groupLabel: z.string().nullable(),
  groupOrder: z.number().nullable(),
  rowType: cardStatementRowTypeSchema,
  editable: z.boolean(),
  dateRaw: z.string().nullable(),
  dateIso: z.string().nullable(),
  markerRaw: z.string().nullable(),
  referenceRaw: z.string().nullable(),
  installmentRaw: z.string().nullable(),
  installmentCurrent: z.number().nullable(),
  installmentTotal: z.number().nullable(),
  receiptRaw: z.string().nullable(),
  amountPesos: z.string().nullable(),
  amountDollars: z.string().nullable(),
  currencyOriginal: currencyOriginalSchema,
  originalText: z.string(),
  confidence: z.number().nullable(),
  warnings: z.array(z.string()),
});

export const cardStatementSectionSchema = z.object({
  id: z.string(),
  displayOrder: z.number(),
  label: z.string(),
});

export const cardStatementGroupSchema = z.object({
  id: z.string(),
  displayOrder: z.number(),
  label: z.string(),
  cardLast4: z.string().nullable(),
  holderName: z.string().nullable(),
});

export const cardStatementPreviewSchema = z.object({
  statementId: z.string().nullable(),
  source: z.object({
    bankName: z.string().nullable(),
    brand: z.string().nullable(),
    statementNumber: z.string().nullable(),
    pageCount: z.number(),
  }),
  summary: z.object({
    totalPesos: z.string().nullable(),
    totalDollars: z.string().nullable(),
    minimumPaymentPesos: z.string().nullable(),
    currentDueDate: z.string().nullable(),
    nextClosingDate: z.string().nullable(),
    nextDueDate: z.string().nullable(),
  }),
  sections: z.array(cardStatementSectionSchema),
  groups: z.array(cardStatementGroupSchema),
  rows: z.array(cardStatementRowSchema),
  futureInstallmentsBlock: z.array(cardStatementRowSchema),
});

export const importResultSchema = z.object({
  draftId: z.string(),
  document: z.object({
    id: z.string(),
    fileName: z.string(),
    mimeType: z.string(),
    sha256: z.string(),
    pageCount: z.number(),
  }),
  status: z.string(),
  warnings: z.array(z.string()),
  preview: cardStatementPreviewSchema,
});

export const manualPurchaseSchema = z.object({
  cardLast4: z.string().length(4),
  holderName: z.string().min(1),
  purchaseDate: z.string(),
  description: z.string().min(1),
  currency: z.enum(["ARS", "USD"]),
  amount: z.string(),
  installments: z.number().int().positive(),
  notes: z.string().optional(),
});

export type CardStatementRowInput = z.infer<typeof cardStatementRowSchema>;
export type CardStatementPreviewInput = z.infer<typeof cardStatementPreviewSchema>;
export type ManualPurchaseInput = z.infer<typeof manualPurchaseSchema>;
