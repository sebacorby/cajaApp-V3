import { prisma } from "../../db/prisma.js";
import { validateData } from "../../shared/validation.js";
import { manualPurchaseSchema, type ManualPurchaseInput } from "../cards/cards.schemas.js";
import { logger } from "../../shared/logger.js";
import { getMonthKey, getMonthLabel, addMonths } from "../../shared/dates.js";
import { parseArgentinePesos } from "../../shared/money.js";

export class ManualPurchasesService {
  async createPurchase(statementId: string, input: ManualPurchaseInput) {
    const validated = validateData(manualPurchaseSchema, input);

    const purchase = await prisma.manualCardPurchase.create({
      data: {
        statementId,
        cardLast4: validated.cardLast4,
        holderName: validated.holderName,
        purchaseDate: validated.purchaseDate,
        description: validated.description,
        currency: validated.currency,
        amountRaw: validated.amount,
        installments: validated.installments,
        notes: validated.notes || null,
      },
    });

    const statementMonthKey = getMonthKey(validated.purchaseDate);
    const projections: Array<{
      statementId: string;
      rowId: string;
      monthKey: string;
      label: string;
      installmentCurrent: number | null;
      installmentTotal: number | null;
      amountPesosRaw: string | null;
      amountDollarsRaw: string | null;
      currencyOriginal: string;
      isManual: boolean;
    }> = [];

    const amountCents = parseArgentinePesos(validated.amount);
    const installmentCents = amountCents / BigInt(validated.installments);
    const remainder = amountCents % BigInt(validated.installments);

    for (let i = 1; i <= validated.installments; i++) {
      let installmentAmount = installmentCents;

      if (i === 1 && remainder > BigInt(0)) {
        installmentAmount += remainder;
      }

      const monthKey = addMonths(statementMonthKey, i - 1);

      projections.push({
        statementId,
        rowId: purchase.id,
        monthKey,
        label: getMonthLabel(monthKey),
        installmentCurrent: i,
        installmentTotal: validated.installments,
        amountPesosRaw: validated.currency === "ARS"
          ? (Number(installmentAmount) / 100).toLocaleString("es-AR", {
              minimumFractionDigits: 2,
              maximumFractionDigits: 2,
            })
          : null,
        amountDollarsRaw: validated.currency === "USD"
          ? (Number(installmentAmount) / 100).toLocaleString("en-US", {
              minimumFractionDigits: 2,
              maximumFractionDigits: 2,
            })
          : null,
        currencyOriginal: validated.currency,
        isManual: true,
      });
    }

    await prisma.cardInstallmentProjection.createMany({
      data: projections,
    });

    logger.info({
      purchaseId: purchase.id,
      statementId,
      installments: validated.installments,
      projectionsCreated: projections.length,
    }, "Manual purchase created with projections");

    return {
      purchase,
      projections,
    };
  }
}

export const manualPurchasesService = new ManualPurchasesService();
