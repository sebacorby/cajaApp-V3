import dotenv from "dotenv";
import path from "path";
import { z } from "zod";

dotenv.config();

const envSchema = z.object({
  NODE_ENV: z.enum(["development", "production", "test"]).default("development"),
  PORT: z.coerce.number().default(4000),
  HOST: z.string().default("127.0.0.1"),
  DATABASE_URL: z.string().default("file:./dev.db"),
  STORAGE_DIR: z.string().default("./storage"),
  MAX_UPLOAD_BYTES: z.coerce.number().default(10485760),
  OLLAMA_BASE_URL: z.string().default("https://ollama.com"),
  OLLAMA_API_KEY: z.string().default(""),
  OLLAMA_MODEL: z.string().default(""),
  OLLAMA_TIMEOUT_MS: z.coerce.number().default(120000),
  OLLAMA_MAX_RETRIES: z.coerce.number().default(2),
  CARD_STATEMENT_PROMPTS_DIR: z.string().default("../../contracts/prompts/cards"),
  AI_MOCK_MODE: z.enum(["true", "false"]).transform(v => v === "true").default("false"),
});

const parsed = envSchema.safeParse(process.env);

if (!parsed.success) {
  console.error("Invalid environment variables:", parsed.error.flatten().fieldErrors);
  process.exit(1);
}

const nodeVersion = process.version;
if (!nodeVersion.startsWith("v22")) {
  console.error(`Node.js 22.x required, found ${nodeVersion}`);
  process.exit(1);
}

export const env = parsed.data;

export const isDev = env.NODE_ENV === "development";
export const isTest = env.NODE_ENV === "test";
export const isProd = env.NODE_ENV === "production";
