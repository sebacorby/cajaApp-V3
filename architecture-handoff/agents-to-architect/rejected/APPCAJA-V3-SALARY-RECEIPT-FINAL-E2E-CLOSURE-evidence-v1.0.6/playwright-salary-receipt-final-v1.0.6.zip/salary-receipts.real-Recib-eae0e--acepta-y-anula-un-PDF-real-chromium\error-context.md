# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: salary-receipts.real.spec.ts >> Recibos de sueldo importa, acepta y anula un PDF real
- Location: tests\salary-receipts.real.spec.ts:16:5

# Error details

```
TypeError: page.getByDisplayValue is not a function
```

# Page snapshot

```yaml
- generic [ref=e1]:
  - generic [ref=e3]:
    - complementary [ref=e4]:
      - generic [ref=e6]:
        - generic [ref=e8]:
          - img [ref=e10]
          - generic [ref=e13]:
            - generic [ref=e14]: CajaApp
            - generic [ref=e15]: Finanzas personales
        - navigation [ref=e16]:
          - paragraph [ref=e17]: Menú
          - button "Inicio" [ref=e18]:
            - img [ref=e19]
            - generic [ref=e24]: Inicio
          - button "Movimientos" [ref=e25]:
            - img [ref=e26]
            - generic [ref=e29]: Movimientos
          - button "Ingresos" [active] [ref=e30]:
            - img [ref=e31]
            - generic [ref=e34]: Ingresos
          - button "Tarjetas" [ref=e36]:
            - img [ref=e37]
            - generic [ref=e39]: Tarjetas
          - button "Deuda futura" [ref=e40]:
            - img [ref=e41]
            - generic [ref=e43]: Deuda futura
          - button "Presupuestos" [ref=e44]:
            - img [ref=e45]
            - generic [ref=e48]: Presupuestos
          - button "Objetivos" [ref=e49]:
            - img [ref=e50]
            - generic [ref=e54]: Objetivos
          - button "Reportes" [ref=e55]:
            - img [ref=e56]
            - generic [ref=e58]: Reportes
          - button "Salud financiera" [ref=e59]:
            - img [ref=e60]
            - generic [ref=e63]: Salud financiera
          - button "Asesor IA" [ref=e64]:
            - img [ref=e65]
            - generic [ref=e67]: Asesor IA
          - button "Configuración" [ref=e68]:
            - img [ref=e69]
            - generic [ref=e72]: Configuración
        - generic [ref=e73]: Datos locales. CajaApp no conecta cuentas bancarias ni toma decisiones financieras por vos.
    - generic [ref=e74]:
      - banner [ref=e75]:
        - generic [ref=e76]:
          - generic [ref=e77]:
            - generic [ref=e78]: CajaApp
            - generic [ref=e79]: Así están tus finanzas, Javi
          - generic [ref=e80]:
            - combobox "Seleccionar período" [ref=e81]:
              - generic: Mes actual
              - img
            - generic [ref=e82]: 01 de jul de 2026 – 31 de jul de 2026
            - button "Buscar en CajaApp" [ref=e83]:
              - img
              - generic [ref=e84]: Buscar
            - button "Centro de alertas, sin alertas activas" [ref=e85]:
              - img
            - button "Nuevo movimiento" [ref=e86]:
              - img
              - generic [ref=e87]: Nuevo movimiento
      - main [ref=e88]:
        - generic [ref=e89]:
          - paragraph [ref=e91]: Sueldos, bonos y proyecciones
          - generic [ref=e92]:
            - generic [ref=e93]:
              - generic [ref=e94]:
                - heading "Ingresos" [level=1] [ref=e95]
                - paragraph [ref=e96]: Sueldos, aumentos, bonos y valores reales calculados por el backend.
              - generic [ref=e97]:
                - button "Actualizar" [ref=e98]:
                  - img
                  - text: Actualizar
                - button "Bono / extra" [ref=e99]:
                  - img
                  - text: Bono / extra
                - button "Nueva fuente" [ref=e100]:
                  - img
                  - text: Nueva fuente
            - generic [ref=e101]:
              - generic [ref=e104]:
                - generic [ref=e105]:
                  - paragraph [ref=e106]: Total del mes
                  - paragraph [ref=e107]: $ 0,00
                  - paragraph [ref=e108]: ARS y USD se muestran separados
                - img [ref=e110]
              - generic [ref=e115]:
                - generic [ref=e116]:
                  - paragraph [ref=e117]: Recurrentes
                  - paragraph [ref=e118]: $ 0,00
                  - paragraph [ref=e119]: 0 fuentes incluidas este mes
                - img [ref=e121]
              - generic [ref=e127]:
                - generic [ref=e128]:
                  - paragraph [ref=e129]: Bonos y extras
                  - paragraph [ref=e130]: $ 0,00
                  - paragraph [ref=e131]: 0 eventos este mes
                - img [ref=e133]
              - generic [ref=e138]:
                - generic [ref=e139]:
                  - paragraph [ref=e140]: Horizonte
                  - paragraph [ref=e141]: 16 meses
                  - paragraph [ref=e142]: 2026-04 a 2027-07
                - img [ref=e144]
            - generic [ref=e146]:
              - generic [ref=e147]:
                - generic [ref=e148]:
                  - generic [ref=e149]:
                    - img [ref=e150]
                    - text: Recibos de sueldo
                  - paragraph [ref=e153]: Importá el PDF, revisá los conceptos y convertí el neto en un ingreso real sin duplicarlo.
                - button "Descartar borrador" [ref=e154]:
                  - img
              - generic [ref=e155]:
                - status [ref=e156]:
                  - img [ref=e157]
                  - generic [ref=e160]: Recibo interpretado. Revisá los datos antes de aceptarlo.
                - generic [ref=e161]:
                  - generic [ref=e162]:
                    - generic [ref=e163]:
                      - generic [ref=e164]: Empleador
                      - textbox [ref=e165]: EMPRESA DEMO S.A.
                    - generic [ref=e166]:
                      - generic [ref=e167]: CUIT empleador
                      - textbox [ref=e168]: 30-00000000-0
                    - generic [ref=e169]:
                      - generic [ref=e170]: Empleado
                      - textbox [ref=e171]: PERSONA DE PRUEBA
                    - generic [ref=e172]:
                      - generic [ref=e173]: CUIL empleado
                      - textbox [ref=e174]: 20-00000000-0
                    - generic [ref=e175]:
                      - generic [ref=e176]: Período
                      - textbox [ref=e177]: 2026-06
                    - generic [ref=e178]:
                      - generic [ref=e179]: Fecha de pago
                      - textbox [ref=e180]: 2026-07-04
                    - generic [ref=e181]:
                      - generic [ref=e182]: Moneda
                      - combobox [ref=e183]:
                        - option "ARS" [selected]
                        - option "USD"
                    - generic [ref=e184]:
                      - generic [ref=e185]: Archivo
                      - generic "salary-receipt-e2e-1784217826133-50d0f5a45b54.pdf" [ref=e186]:
                        - generic [ref=e187]: salary-receipt-e2e-1784217826133-50d0f5a45b54.pdf
                  - generic [ref=e188]:
                    - generic [ref=e189]:
                      - paragraph [ref=e190]: Bruto
                      - paragraph [ref=e191]: $ 1.400.000,00
                    - generic [ref=e192]:
                      - paragraph [ref=e193]: Descuentos
                      - paragraph [ref=e194]: $ 238.000,00
                    - generic [ref=e195]:
                      - paragraph [ref=e196]: Neto a cobrar
                      - paragraph [ref=e197]: $ 1.162.000,00
                  - generic [ref=e198]:
                    - generic [ref=e199]:
                      - generic [ref=e200]:
                        - paragraph [ref=e201]: Conceptos del recibo
                        - paragraph [ref=e202]: El backend recalcula los totales al guardar el borrador.
                      - button "Concepto" [ref=e203]:
                        - img
                        - text: Concepto
                    - generic [ref=e204]:
                      - generic [ref=e205]:
                        - generic [ref=e206]:
                          - generic [ref=e207]: Tipo
                          - combobox [ref=e208]:
                            - option "Haber" [selected]
                            - option "Descuento"
                            - option "Contribución patronal"
                            - option "Informativo"
                        - generic [ref=e209]:
                          - generic [ref=e210]: Código
                          - textbox [ref=e211]: "001"
                        - generic [ref=e212]:
                          - generic [ref=e213]: Descripción
                          - textbox [ref=e214]: Sueldo basico
                        - generic [ref=e215]:
                          - generic [ref=e216]: Importe
                          - textbox [ref=e217]: "1200000.00"
                        - button "Eliminar Sueldo basico" [ref=e218]:
                          - img
                      - generic [ref=e219]:
                        - generic [ref=e220]:
                          - generic [ref=e221]: Tipo
                          - combobox [ref=e222]:
                            - option "Haber" [selected]
                            - option "Descuento"
                            - option "Contribución patronal"
                            - option "Informativo"
                        - generic [ref=e223]:
                          - generic [ref=e224]: Código
                          - textbox [ref=e225]: "010"
                        - generic [ref=e226]:
                          - generic [ref=e227]: Descripción
                          - textbox [ref=e228]: Presentismo
                        - generic [ref=e229]:
                          - generic [ref=e230]: Importe
                          - textbox [ref=e231]: "120000.00"
                        - button "Eliminar Presentismo" [ref=e232]:
                          - img
                      - generic [ref=e233]:
                        - generic [ref=e234]:
                          - generic [ref=e235]: Tipo
                          - combobox [ref=e236]:
                            - option "Haber" [selected]
                            - option "Descuento"
                            - option "Contribución patronal"
                            - option "Informativo"
                        - generic [ref=e237]:
                          - generic [ref=e238]: Código
                          - textbox [ref=e239]: "020"
                        - generic [ref=e240]:
                          - generic [ref=e241]: Descripción
                          - textbox [ref=e242]: Adicional no remunerativo
                        - generic [ref=e243]:
                          - generic [ref=e244]: Importe
                          - textbox [ref=e245]: "80000.00"
                        - button "Eliminar Adicional no remunerativo" [ref=e246]:
                          - img
                      - generic [ref=e247]:
                        - generic [ref=e248]:
                          - generic [ref=e249]: Tipo
                          - combobox [ref=e250]:
                            - option "Haber"
                            - option "Descuento" [selected]
                            - option "Contribución patronal"
                            - option "Informativo"
                        - generic [ref=e251]:
                          - generic [ref=e252]: Código
                          - textbox [ref=e253]: "501"
                        - generic [ref=e254]:
                          - generic [ref=e255]: Descripción
                          - textbox [ref=e256]: Jubilacion 11%
                        - generic [ref=e257]:
                          - generic [ref=e258]: Importe
                          - textbox [ref=e259]: "154000.00"
                        - button "Eliminar Jubilacion 11%" [ref=e260]:
                          - img
                      - generic [ref=e261]:
                        - generic [ref=e262]:
                          - generic [ref=e263]: Tipo
                          - combobox [ref=e264]:
                            - option "Haber"
                            - option "Descuento" [selected]
                            - option "Contribución patronal"
                            - option "Informativo"
                        - generic [ref=e265]:
                          - generic [ref=e266]: Código
                          - textbox [ref=e267]: "502"
                        - generic [ref=e268]:
                          - generic [ref=e269]: Descripción
                          - textbox [ref=e270]: Obra social 3%
                        - generic [ref=e271]:
                          - generic [ref=e272]: Importe
                          - textbox [ref=e273]: "42000.00"
                        - button "Eliminar Obra social 3%" [ref=e274]:
                          - img
                      - generic [ref=e275]:
                        - generic [ref=e276]:
                          - generic [ref=e277]: Tipo
                          - combobox [ref=e278]:
                            - option "Haber"
                            - option "Descuento" [selected]
                            - option "Contribución patronal"
                            - option "Informativo"
                        - generic [ref=e279]:
                          - generic [ref=e280]: Código
                          - textbox [ref=e281]: "503"
                        - generic [ref=e282]:
                          - generic [ref=e283]: Descripción
                          - textbox [ref=e284]: Ley 19032 3%
                        - generic [ref=e285]:
                          - generic [ref=e286]: Importe
                          - textbox [ref=e287]: "42000.00"
                        - button "Eliminar Ley 19032 3%" [ref=e288]:
                          - img
                  - generic [ref=e289]:
                    - generic [ref=e290]:
                      - generic [ref=e291]: Fuente salarial vinculada
                      - combobox [ref=e292]:
                        - option "Crear o detectar automáticamente" [selected]
                    - generic [ref=e293]:
                      - checkbox "Usar el neto como nueva base La proyección salarial futura partirá de este recibo. El mes importado siempre queda como valor real." [checked] [ref=e294]
                      - generic [ref=e295]:
                        - strong [ref=e296]: Usar el neto como nueva base
                        - text: La proyección salarial futura partirá de este recibo. El mes importado siempre queda como valor real.
                  - generic [ref=e297]:
                    - button "Guardar borrador" [ref=e298]
                    - button "Aceptar e incorporar" [ref=e299]:
                      - img
                      - text: Aceptar e incorporar
                - generic [ref=e300]:
                  - generic [ref=e301]:
                    - generic [ref=e302]:
                      - paragraph [ref=e303]: Historial reciente
                      - paragraph [ref=e304]: Cada reemplazo conserva su versión y trazabilidad.
                    - button "Actualizar" [ref=e305]:
                      - img
                      - text: Actualizar
                  - generic [ref=e306]: Todavía no hay recibos aceptados.
            - generic [ref=e307]:
              - generic [ref=e308]:
                - generic [ref=e309]:
                  - generic [ref=e310]: Fuentes recurrentes
                  - paragraph [ref=e311]: Cada fuente conserva su base, ajustes y regla de aumento.
                - button "Agregar" [ref=e312]:
                  - img
                  - text: Agregar
              - generic [ref=e314]:
                - img [ref=e315]
                - paragraph [ref=e318]: Todavía no hay fuentes de ingreso
                - paragraph [ref=e319]: Agregá un sueldo o ingreso recurrente para comenzar la proyección.
                - button "Agregar primer ingreso" [ref=e320]:
                  - img
                  - text: Agregar primer ingreso
            - generic [ref=e321]:
              - generic [ref=e322]:
                - generic [ref=e323]: Calendario de ingresos
                - paragraph [ref=e324]: Valores reales y estimados. El frontend sólo presenta el cálculo del backend.
              - generic [ref=e326]:
                - generic [ref=e327]:
                  - generic [ref=e328]:
                    - generic [ref=e329]:
                      - paragraph [ref=e330]: 2026-04
                      - heading "abril de 2026" [level=3] [ref=e331]
                    - paragraph [ref=e333]: $ 0,00
                  - paragraph [ref=e335]: Sin ingresos configurados.
                - generic [ref=e336]:
                  - generic [ref=e337]:
                    - generic [ref=e338]:
                      - paragraph [ref=e339]: 2026-05
                      - heading "mayo de 2026" [level=3] [ref=e340]
                    - paragraph [ref=e342]: $ 0,00
                  - paragraph [ref=e344]: Sin ingresos configurados.
                - generic [ref=e345]:
                  - generic [ref=e346]:
                    - generic [ref=e347]:
                      - paragraph [ref=e348]: 2026-06
                      - heading "junio de 2026" [level=3] [ref=e349]
                    - paragraph [ref=e351]: $ 0,00
                  - paragraph [ref=e353]: Sin ingresos configurados.
                - generic [ref=e354]:
                  - generic [ref=e355]:
                    - generic [ref=e356]:
                      - paragraph [ref=e357]: Mes actual
                      - heading "julio de 2026" [level=3] [ref=e358]
                    - paragraph [ref=e360]: $ 0,00
                  - paragraph [ref=e362]: Sin ingresos configurados.
                - generic [ref=e363]:
                  - generic [ref=e364]:
                    - generic [ref=e365]:
                      - paragraph [ref=e366]: 2026-08
                      - heading "agosto de 2026" [level=3] [ref=e367]
                    - paragraph [ref=e369]: $ 0,00
                  - paragraph [ref=e371]: Sin ingresos configurados.
                - generic [ref=e372]:
                  - generic [ref=e373]:
                    - generic [ref=e374]:
                      - paragraph [ref=e375]: 2026-09
                      - heading "septiembre de 2026" [level=3] [ref=e376]
                    - paragraph [ref=e378]: $ 0,00
                  - paragraph [ref=e380]: Sin ingresos configurados.
                - generic [ref=e381]:
                  - generic [ref=e382]:
                    - generic [ref=e383]:
                      - paragraph [ref=e384]: 2026-10
                      - heading "octubre de 2026" [level=3] [ref=e385]
                    - paragraph [ref=e387]: $ 0,00
                  - paragraph [ref=e389]: Sin ingresos configurados.
                - generic [ref=e390]:
                  - generic [ref=e391]:
                    - generic [ref=e392]:
                      - paragraph [ref=e393]: 2026-11
                      - heading "noviembre de 2026" [level=3] [ref=e394]
                    - paragraph [ref=e396]: $ 0,00
                  - paragraph [ref=e398]: Sin ingresos configurados.
                - generic [ref=e399]:
                  - generic [ref=e400]:
                    - generic [ref=e401]:
                      - paragraph [ref=e402]: 2026-12
                      - heading "diciembre de 2026" [level=3] [ref=e403]
                    - paragraph [ref=e405]: $ 0,00
                  - paragraph [ref=e407]: Sin ingresos configurados.
                - generic [ref=e408]:
                  - generic [ref=e409]:
                    - generic [ref=e410]:
                      - paragraph [ref=e411]: 2027-01
                      - heading "enero de 2027" [level=3] [ref=e412]
                    - paragraph [ref=e414]: $ 0,00
                  - paragraph [ref=e416]: Sin ingresos configurados.
                - generic [ref=e417]:
                  - generic [ref=e418]:
                    - generic [ref=e419]:
                      - paragraph [ref=e420]: 2027-02
                      - heading "febrero de 2027" [level=3] [ref=e421]
                    - paragraph [ref=e423]: $ 0,00
                  - paragraph [ref=e425]: Sin ingresos configurados.
                - generic [ref=e426]:
                  - generic [ref=e427]:
                    - generic [ref=e428]:
                      - paragraph [ref=e429]: 2027-03
                      - heading "marzo de 2027" [level=3] [ref=e430]
                    - paragraph [ref=e432]: $ 0,00
                  - paragraph [ref=e434]: Sin ingresos configurados.
                - generic [ref=e435]:
                  - generic [ref=e436]:
                    - generic [ref=e437]:
                      - paragraph [ref=e438]: 2027-04
                      - heading "abril de 2027" [level=3] [ref=e439]
                    - paragraph [ref=e441]: $ 0,00
                  - paragraph [ref=e443]: Sin ingresos configurados.
                - generic [ref=e444]:
                  - generic [ref=e445]:
                    - generic [ref=e446]:
                      - paragraph [ref=e447]: 2027-05
                      - heading "mayo de 2027" [level=3] [ref=e448]
                    - paragraph [ref=e450]: $ 0,00
                  - paragraph [ref=e452]: Sin ingresos configurados.
                - generic [ref=e453]:
                  - generic [ref=e454]:
                    - generic [ref=e455]:
                      - paragraph [ref=e456]: 2027-06
                      - heading "junio de 2027" [level=3] [ref=e457]
                    - paragraph [ref=e459]: $ 0,00
                  - paragraph [ref=e461]: Sin ingresos configurados.
                - generic [ref=e462]:
                  - generic [ref=e463]:
                    - generic [ref=e464]:
                      - paragraph [ref=e465]: 2027-07
                      - heading "julio de 2027" [level=3] [ref=e466]
                    - paragraph [ref=e468]: $ 0,00
                  - paragraph [ref=e470]: Sin ingresos configurados.
      - contentinfo [ref=e471]:
        - generic [ref=e472]:
          - paragraph [ref=e473]: © 2026 CajaApp.
          - paragraph [ref=e474]: La información se procesa localmente en tu instalación.
  - region "Notifications (F8)":
    - list
  - alert [ref=e475]
```

# Test source

```ts
  1   | import { expect, test } from "@playwright/test";
  2   | import { readFile } from "node:fs/promises";
  3   | import path from "node:path";
  4   | 
  5   | 
  6   | const BACKEND_BASE_URL =
  7   |   process.env.NEXT_PUBLIC_API_BASE_URL || "http://127.0.0.1:11436";
  8   | 
  9   | 
  10  | const BASE_FIXTURE = path.resolve(
  11  |   __dirname,
  12  |   "../../../contracts/examples/salary-receipts/salary-receipt.sanitized.base.pdf",
  13  | );
  14  | 
  15  | 
  16  | test("Recibos de sueldo importa, acepta y anula un PDF real", async ({
  17  |   page,
  18  |   request,
  19  | }) => {
  20  |   test.setTimeout(480_000);
  21  | 
  22  | 
  23  |   let acceptedReceiptId: string | null = null;
  24  |   let reversed = false;
  25  | 
  26  | 
  27  |   try {
  28  |     await page.goto("/");
  29  |     await expect(page.getByText("CajaApp", { exact: true }).first()).toBeVisible();
  30  |     await page.getByRole("button", { name: /^Ingresos$/i }).click();
  31  |     await expect(page.getByTestId("salary-receipts-panel")).toBeVisible();
  32  | 
  33  | 
  34  |     const fixtureBytes = await readFile(BASE_FIXTURE);
  35  |     const runId = `${Date.now()}-${Math.random().toString(16).slice(2)}`;
  36  |     const uniqueFixture = Buffer.concat([
  37  |       fixtureBytes,
  38  |       Buffer.from(`\n% CajaApp salary receipt E2E ${runId}\n`, "utf8"),
  39  |     ]);
  40  | 
  41  | 
  42  |     const importResponsePromise = page.waitForResponse(
  43  |       (response) =>
  44  |         response.url() === `${BACKEND_BASE_URL}/api/salary-receipts/import` &&
  45  |         response.request().method() === "POST",
  46  |       { timeout: 420_000 },
  47  |     );
  48  | 
  49  | 
  50  |     await page.getByTestId("salary-receipt-file").setInputFiles({
  51  |       name: `salary-receipt-e2e-${runId}.pdf`,
  52  |       mimeType: "application/pdf",
  53  |       buffer: uniqueFixture,
  54  |     });
  55  | 
  56  | 
  57  |     const importResponse = await importResponsePromise;
  58  |     const importBody = await importResponse.text();
  59  |     expect(
  60  |       importResponse.status(),
  61  |       `POST /api/salary-receipts/import devolvió ${importResponse.status()}: ${importBody}`,
  62  |     ).toBe(201);
  63  | 
  64  | 
  65  |     const draft = JSON.parse(importBody) as {
  66  |       id: string;
  67  |       preview?: {
  68  |         source?: {
  69  |           employerName?: string;
  70  |           employeeName?: string;
  71  |           periodMonthKey?: string;
  72  |         };
  73  |       };
  74  |     };
  75  | 
  76  | 
  77  |     expect(draft.id).toBeTruthy();
  78  |     expect(draft.preview?.source?.periodMonthKey).toBe("2026-06");
  79  | 
  80  | 
  81  |     const preview = page.getByTestId("salary-receipt-preview");
  82  |     await expect(preview).toBeVisible({ timeout: 15_000 });
  83  |     await expect(preview.locator("input").nth(0)).toHaveValue(/EMPRESA DEMO S\.A\./i);
  84  |     await expect(preview.locator("input").nth(2)).toHaveValue(/PERSONA DE PRUEBA/i);
  85  |     await expect(preview.locator('input[type="month"]')).toHaveValue("2026-06");
> 86  |     await expect(page.getByDisplayValue(/Sueldo b[aá]sico/i)).toBeVisible();
      |                       ^ TypeError: page.getByDisplayValue is not a function
  87  |     await expect(preview).toContainText("Neto a cobrar");
  88  |     await expect(preview.getByRole("checkbox")).toBeChecked();
  89  | 
  90  | 
  91  |     const acceptResponsePromise = page.waitForResponse(
  92  |       (response) =>
  93  |         response.url() ===
  94  |           `${BACKEND_BASE_URL}/api/salary-receipts/drafts/${draft.id}/accept` &&
  95  |         response.request().method() === "POST",
  96  |       { timeout: 60_000 },
  97  |     );
  98  | 
  99  | 
  100 |     await page.getByTestId("accept-salary-receipt").click();
  101 | 
  102 | 
  103 |     const acceptResponse = await acceptResponsePromise;
  104 |     const acceptBody = await acceptResponse.text();
  105 |     expect(
  106 |       acceptResponse.status(),
  107 |       `POST /accept devolvió ${acceptResponse.status()}: ${acceptBody}`,
  108 |     ).toBe(201);
  109 | 
  110 | 
  111 |     const accepted = JSON.parse(acceptBody) as {
  112 |       id: string;
  113 |       periodMonthKey: string;
  114 |       employerName: string;
  115 |       actualIncomeEventId: string | null;
  116 |       projectionIncomeEventId: string | null;
  117 |     };
  118 | 
  119 | 
  120 |     acceptedReceiptId = accepted.id;
  121 |     expect(accepted.periodMonthKey).toBe("2026-06");
  122 |     expect(accepted.employerName).toMatch(/EMPRESA DEMO S\.A\./i);
  123 |     expect(accepted.actualIncomeEventId).toBeTruthy();
  124 |     expect(accepted.projectionIncomeEventId).toBeTruthy();
  125 | 
  126 | 
  127 |     await expect(page.getByText(/Recibo 2026-06 aceptado/i)).toBeVisible();
  128 |     await expect(page.getByText(/2026-06 · EMPRESA DEMO S\.A\./i)).toBeVisible();
  129 | 
  130 | 
  131 |     page.once("dialog", (dialog) => dialog.accept());
  132 | 
  133 | 
  134 |     const reverseResponsePromise = page.waitForResponse(
  135 |       (response) =>
  136 |         response.url() ===
  137 |           `${BACKEND_BASE_URL}/api/salary-receipts/${acceptedReceiptId}/reverse` &&
  138 |         response.request().method() === "POST",
  139 |       { timeout: 30_000 },
  140 |     );
  141 | 
  142 | 
  143 |     await page.getByRole("button", { name: /^Anular$/i }).click();
  144 | 
  145 | 
  146 |     const reverseResponse = await reverseResponsePromise;
  147 |     const reverseBody = await reverseResponse.text();
  148 |     expect(
  149 |       reverseResponse.status(),
  150 |       `POST /reverse devolvió ${reverseResponse.status()}: ${reverseBody}`,
  151 |     ).toBe(200);
  152 | 
  153 | 
  154 |     reversed = true;
  155 |     await expect(
  156 |       page.getByText("Recibo anulado y movimientos vinculados eliminados."),
  157 |     ).toBeVisible();
  158 |   } finally {
  159 |     if (acceptedReceiptId && !reversed) {
  160 |       await request.post(
  161 |         `${BACKEND_BASE_URL}/api/salary-receipts/${acceptedReceiptId}/reverse`,
  162 |       );
  163 |     }
  164 |   }
  165 | });
```