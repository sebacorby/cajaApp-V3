import type { FinanceSnapshot } from "./types";

/**
 * Datos mock realistas para el prototipo.
 * Separados de la UI para permitir iterar visualmente sin tocar la lógica.
 * Los valores son representativos de un perfil profesional de Buenos Aires.
 */

export const financeSnapshot: FinanceSnapshot = {
  user: {
    name: "Valentina",
    greeting: "Hola, Valentina",
    account: "Cuenta · ···· 4827",
  },

  summary: {
    balance: 1842500,
    balanceVariation: 8.4,
    income: 1280000,
    incomeVariation: 4.1,
    expenses: 768400,
    expensesVariation: -3.2,
    savings: 511600,
    savingsRate: 0.4,
  },

  budgetSummary: {
    totalLimit: 820000,
    totalSpent: 768400,
  },

  categories: [
    { id: "cat-hogar", name: "Hogar y servicios", color: "#0d9488", icon: "home", amount: 284000 },
    { id: "cat-comida", name: "Supermercado", color: "#10b981", icon: "shopping-cart", amount: 196500 },
    { id: "cat-transporte", name: "Transporte", color: "#f59e0b", icon: "car", amount: 98200 },
    { id: "cat-ocio", name: "Ocio y restaurantes", color: "#ec4899", icon: "utensils", amount: 84600 },
    { id: "cat-salud", name: "Salud y bienestar", color: "#14b8a6", icon: "heart-pulse", amount: 62400 },
    { id: "cat-otros", name: "Otros", color: "#64748b", icon: "package", amount: 42700 },
  ],

  budgets: [
    { id: "bud-hogar", category: "Hogar y servicios", spent: 284000, limit: 300000 },
    { id: "bud-comida", category: "Supermercado", spent: 196500, limit: 200000 },
    { id: "bud-transporte", category: "Transporte", spent: 98200, limit: 90000 },
    { id: "bud-ocio", category: "Ocio y restaurantes", spent: 84600, limit: 120000 },
    { id: "bud-salud", category: "Salud y bienestar", spent: 62400, limit: 80000 },
    { id: "bud-otros", category: "Otros", spent: 42700, limit: 30000 },
  ],

  transactions: [
    { id: "t-01", date: "2025-03-18", description: "Salario mensual", category: "Sueldo", amount: 1280000, type: "income", status: "completed" },
    { id: "t-02", date: "2025-03-17", description: "Alquiler departamento", category: "Hogar y servicios", amount: 240000, type: "expense", status: "completed" },
    { id: "t-03", date: "2025-03-16", description: "Carrefour Express", category: "Supermercado", amount: 42800, type: "expense", status: "completed" },
    { id: "t-04", date: "2025-03-15", description: "Uber viaje", category: "Transporte", amount: 6240, type: "expense", status: "completed" },
    { id: "t-05", date: "2025-03-14", description: "Netflix suscripción", category: "Ocio y restaurantes", amount: 12900, type: "expense", status: "completed" },
    { id: "t-06", date: "2025-03-13", description: "Farmacia San Roque", category: "Salud y bienestar", amount: 18750, type: "expense", status: "completed" },
    { id: "t-07", date: "2025-03-12", description: "Transferencia recibida", category: "Ingresos extra", amount: 45000, type: "income", status: "pending" },
    { id: "t-08", date: "2025-03-11", description: "Restaurante Tegui", category: "Ocio y restaurantes", amount: 58200, type: "expense", status: "completed" },
    { id: "t-09", date: "2025-03-10", description: "Edesur factura", category: "Hogar y servicios", amount: 38400, type: "expense", status: "completed" },
    { id: "t-10", date: "2025-03-09", description: "Carga nafta YPF", category: "Transporte", amount: 51600, type: "expense", status: "completed" },
    { id: "t-11", date: "2025-03-08", description: " Spotify Premium", category: "Ocio y restaurantes", amount: 4990, type: "expense", status: "completed" },
    { id: "t-12", date: "2025-03-07", description: "Freelance diseño", category: "Ingresos extra", amount: 96000, type: "income", status: "completed" },
  ],

  goals: [
    { id: "g-1", name: "Fondo de emergencia", target: 3000000, current: 1842500, deadline: "2025-09-30", icon: "shield-check" },
    { id: "g-2", name: "Viaje a Bariloche", target: 1200000, current: 768000, deadline: "2025-07-15", icon: "plane" },
    { id: "g-3", name: "Notebook nueva", target: 980000, current: 612000, deadline: "2025-06-01", icon: "laptop" },
    { id: "g-4", name: "Curso de inversión", target: 180000, current: 180000, deadline: "2025-03-31", icon: "graduation-cap" },
  ],

  alerts: [
    {
      id: "a-1",
      severity: "warning",
      title: "Transporte superó el presupuesto",
      detail: "Gastaste $98.200 de un límite de $90.000 en Transporte este mes.",
      icon: "triangle-alert",
    },
    {
      id: "a-2",
      severity: "success",
      title: "Buen ritmo de ahorro",
      detail: "Tu tasa de ahorro es del 40 %, por encima del promedio del último semestre.",
      icon: "trending-up",
    },
    {
      id: "a-3",
      severity: "info",
      title: "Ingreso pendiente de acreditación",
      detail: "Hay una transferencia de $45.000 en proceso de verificación.",
      icon: "clock",
    },
    {
      id: "a-4",
      severity: "danger",
      title: "Categoría Otros fuera de control",
      detail: "Superaste el presupuesto de Otros en un 42 %. Revisá los gastos no clasificados.",
      icon: "circle-alert",
    },
  ],

  evolution: [
    { month: "Sep", income: 1120000, expenses: 802000, savings: 318000 },
    { month: "Oct", income: 1180000, expenses: 845000, savings: 335000 },
    { month: "Nov", income: 1180000, expenses: 790000, savings: 390000 },
    { month: "Dic", income: 1340000, expenses: 980000, savings: 360000 },
    { month: "Ene", income: 1240000, expenses: 815000, savings: 425000 },
    { month: "Feb", income: 1230000, expenses: 793000, savings: 437000 },
    { month: "Mar", income: 1280000, expenses: 768400, savings: 511600 },
  ],

  healthScore: 78,
};
