/**
 * Tipos del dominio de finanzas personales.
 * Centralizan la forma de los datos que consume la UI.
 */

export type TransactionType = "income" | "expense";

export type TransactionStatus = "completed" | "pending";

export interface Transaction {
  id: string;
  date: string; // ISO (yyyy-mm-dd)
  description: string;
  category: string;
  amount: number;
  type: TransactionType;
  status: TransactionStatus;
}

export interface Category {
  id: string;
  name: string;
  /** Color de acento usado en chips y gráficos. */
  color: string;
  /** Nombre del ícono de lucide-react en kebab-case. */
  icon: string;
  amount: number;
}

export interface Budget {
  id: string;
  category: string;
  spent: number;
  limit: number;
}

export interface Goal {
  id: string;
  name: string;
  target: number;
  current: number;
  /** ISO date. */
  deadline: string;
  icon: string;
}

export type AlertSeverity = "info" | "warning" | "danger" | "success";

export interface SmartAlert {
  id: string;
  severity: AlertSeverity;
  title: string;
  detail: string;
  icon: string;
}

export interface MonthlyPoint {
  month: string; // etiqueta corta, ej: "Ene"
  income: number;
  expenses: number;
  savings: number;
}

export interface MonthlySummary {
  balance: number;
  balanceVariation: number; // porcentaje
  income: number;
  incomeVariation: number;
  expenses: number;
  expensesVariation: number;
  savings: number;
  savingsRate: number; // 0..1
}

export interface BudgetSummary {
  totalLimit: number;
  totalSpent: number;
}

export interface UserProfile {
  name: string;
  greeting: string;
  account: string;
}

export interface FinanceSnapshot {
  user: UserProfile;
  summary: MonthlySummary;
  categories: Category[];
  budgets: Budget[];
  budgetSummary: BudgetSummary;
  transactions: Transaction[];
  goals: Goal[];
  alerts: SmartAlert[];
  evolution: MonthlyPoint[];
  healthScore: number; // 0..100
}
