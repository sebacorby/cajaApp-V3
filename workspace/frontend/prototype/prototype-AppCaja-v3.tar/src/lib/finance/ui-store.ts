"use client";

import { create } from "zustand";

export type SectionId =
  | "dashboard"
  | "movimientos"
  | "presupuestos"
  | "objetivos"
  | "reportes"
  | "configuracion";

export type Period = "mes" | "trimestre" | "semestre" | "anio";

export type UIMode = "normal" | "loading" | "empty" | "error";

interface FinanceUIState {
  section: SectionId;
  period: Period;
  mode: UIMode;
  setSection: (s: SectionId) => void;
  setPeriod: (p: Period) => void;
  setMode: (m: UIMode) => void;
}

export const useFinanceUI = create<FinanceUIState>((set) => ({
  section: "dashboard",
  period: "mes",
  mode: "normal",
  setSection: (section) => set({ section }),
  setPeriod: (period) => set({ period }),
  setMode: (mode) => set({ mode }),
}));

export const PERIOD_LABELS: Record<Period, string> = {
  mes: "Este mes",
  trimestre: "Trimestre",
  semestre: "Semestre",
  anio: "Año",
};

export const PERIOD_SHORT: Record<Period, string> = {
  mes: "Marzo 2025",
  trimestre: "Q1 2025",
  semestre: "H1 2025",
  anio: "2025",
};
