"use client";

import { AppShell } from "@/components/finance/layout/app-shell";
import { SectionRouter } from "@/components/finance/sections/section-router";
import { DemoStateControl } from "@/components/finance/layout/demo-state-control";

export default function Home() {
  return (
    <>
      <AppShell>
        <SectionRouter />
      </AppShell>
      <DemoStateControl />
    </>
  );
}
