import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "Clarified — Gestión de finanzas personales",
  description: "Dashboard de finanzas personales: balance, ingresos, gastos, ahorro, presupuestos y objetivos en un solo lugar.",
  keywords: ["finanzas personales", "dashboard", "presupuesto", "ahorro", "balance", "objetivos"],
  authors: [{ name: "Clarified" }],
  icons: {
    icon: "https://z-cdn.chatglm.cn/z-ai/static/logo.svg",
  },
  openGraph: {
    title: "Clarified — Finanzas personales con claridad",
    description: "Entendé y ordená tus finanzas en segundos.",
    url: "https://chat.z.ai",
    siteName: "Clarified",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "Clarified — Finanzas personales",
    description: "Entendé y ordená tus finanzas en segundos.",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="es" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
