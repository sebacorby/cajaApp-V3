"use client";

import { useState } from "react";
import type { Transaction } from "@/lib/finance/types";
import {
  formatCurrency,
  formatDateShort,
  formatDate,
} from "@/lib/finance/format";
import { cn } from "@/lib/utils";
import { ArrowDownLeft, ArrowUpRight, Clock } from "lucide-react";

interface TransactionsListProps {
  transactions: Transaction[];
  limit?: number;
  /** Muestra los controles de filtro de tipo. */
  filterable?: boolean;
}

type Filter = "all" | "income" | "expense";

export function TransactionsList({
  transactions,
  limit,
  filterable = false,
}: TransactionsListProps) {
  const [filter, setFilter] = useState<Filter>("all");

  const filtered = transactions.filter((t) =>
    filter === "all" ? true : t.type === filter
  );
  const visible = limit ? filtered.slice(0, limit) : filtered;

  return (
    <div className="flex flex-col gap-3">
      {filterable && (
        <div className="flex items-center gap-1 self-start rounded-full border bg-card p-1 text-xs">
          {(
            [
              { id: "all", label: "Todos" },
              { id: "income", label: "Ingresos" },
              { id: "expense", label: "Gastos" },
            ] as const
          ).map((f) => (
            <button
              key={f.id}
              type="button"
              onClick={() => setFilter(f.id)}
              className={cn(
                "rounded-full px-3 py-1 font-medium transition-colors",
                filter === f.id
                  ? "bg-primary text-primary-foreground"
                  : "text-muted-foreground hover:text-foreground"
              )}
            >
              {f.label}
            </button>
          ))}
        </div>
      )}

      {/* Tabla en desktop */}
      <div className="hidden overflow-hidden rounded-2xl border sm:block">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b bg-muted/40 text-left text-xs text-muted-foreground">
              <th className="px-4 py-2.5 font-medium">Fecha</th>
              <th className="px-4 py-2.5 font-medium">Descripción</th>
              <th className="px-4 py-2.5 font-medium">Categoría</th>
              <th className="px-4 py-2.5 font-medium">Estado</th>
              <th className="px-4 py-2.5 text-right font-medium">Monto</th>
            </tr>
          </thead>
          <tbody>
            {visible.map((t) => (
              <tr
                key={t.id}
                className="border-b last:border-0 transition-colors hover:bg-muted/30"
              >
                <td className="whitespace-nowrap px-4 py-3 text-muted-foreground">
                  {formatDateShort(t.date)}
                </td>
                <td className="px-4 py-3">
                  <div className="flex items-center gap-2.5">
                    <span
                      className={cn(
                        "grid size-8 shrink-0 place-items-center rounded-lg",
                        t.type === "income"
                          ? "bg-emerald-50 text-emerald-600"
                          : "bg-rose-50 text-rose-600"
                      )}
                    >
                      {t.type === "income" ? (
                        <ArrowDownLeft className="size-4" />
                      ) : (
                        <ArrowUpRight className="size-4" />
                      )}
                    </span>
                    <span className="font-medium text-foreground">
                      {t.description}
                    </span>
                  </div>
                </td>
                <td className="whitespace-nowrap px-4 py-3 text-muted-foreground">
                  {t.category}
                </td>
                <td className="px-4 py-3">
                  {t.status === "completed" ? (
                    <span className="rounded-full bg-emerald-50 px-2 py-0.5 text-xs font-medium text-emerald-700">
                      Acreditado
                    </span>
                  ) : (
                    <span className="inline-flex items-center gap-1 rounded-full bg-amber-50 px-2 py-0.5 text-xs font-medium text-amber-700">
                      <Clock className="size-3" />
                      Pendiente
                    </span>
                  )}
                </td>
                <td
                  className={cn(
                    "whitespace-nowrap px-4 py-3 text-right font-semibold tabular-nums",
                    t.type === "income" ? "text-emerald-700" : "text-foreground"
                  )}
                >
                  {t.type === "income" ? "+" : "−"}
                  {formatCurrency(t.amount)}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Tarjetas en mobile */}
      <ul className="flex flex-col gap-2 sm:hidden">
        {visible.map((t) => (
          <li
            key={t.id}
            className="flex items-center gap-3 rounded-xl border bg-card p-3"
          >
            <span
              className={cn(
                "grid size-9 shrink-0 place-items-center rounded-lg",
                t.type === "income"
                  ? "bg-emerald-50 text-emerald-600"
                  : "bg-rose-50 text-rose-600"
              )}
            >
              {t.type === "income" ? (
                <ArrowDownLeft className="size-4" />
              ) : (
                <ArrowUpRight className="size-4" />
              )}
            </span>
            <div className="min-w-0 flex-1">
              <p className="truncate text-sm font-medium text-foreground">
                {t.description}
              </p>
              <p className="text-xs text-muted-foreground">
                {formatDate(t.date)} · {t.category}
              </p>
            </div>
            <div className="flex flex-col items-end gap-0.5">
              <span
                className={cn(
                  "text-sm font-semibold tabular-nums",
                  t.type === "income"
                    ? "text-emerald-700"
                    : "text-foreground"
                )}
              >
                {t.type === "income" ? "+" : "−"}
                {formatCurrency(t.amount)}
              </span>
              {t.status === "pending" && (
                <span className="text-[10px] font-medium text-amber-600">
                  Pendiente
                </span>
              )}
            </div>
          </li>
        ))}
      </ul>

      {visible.length === 0 && (
        <div className="rounded-xl border border-dashed py-8 text-center text-sm text-muted-foreground">
          No hay movimientos para este filtro.
        </div>
      )}
    </div>
  );
}
