"use client";

import type { Goal } from "@/lib/finance/types";
import {
  formatCurrency,
  formatPercent,
  computeProgress,
  formatDate,
} from "@/lib/finance/format";
import { getIcon } from "@/lib/finance/icons";
import { cn } from "@/lib/utils";
import { Check } from "lucide-react";

interface GoalsGridProps {
  goals: Goal[];
}

function goalTone(progress: number) {
  if (progress >= 1) return { ring: "text-emerald-600", bar: "bg-emerald-500" };
  if (progress >= 0.75) return { ring: "text-emerald-600", bar: "bg-emerald-500" };
  if (progress >= 0.4) return { ring: "text-amber-600", bar: "bg-amber-500" };
  return { ring: "text-slate-500", bar: "bg-slate-400" };
}

export function GoalsGrid({ goals }: GoalsGridProps) {
  return (
    <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
      {goals.map((g) => {
        const progress = computeProgress(g.current, g.target);
        const tone = goalTone(progress);
        const Icon = getIcon(g.icon);
        const complete = progress >= 1;
        return (
          <article
            key={g.id}
            className="group flex flex-col gap-3 rounded-2xl border bg-card p-4 shadow-sm transition-all hover:shadow-md"
          >
            <div className="flex items-start gap-3">
              <span
                className={cn(
                  "grid size-10 shrink-0 place-items-center rounded-xl bg-muted",
                  tone.ring
                )}
              >
                <Icon className="size-5" />
              </span>
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-2">
                  <h4 className="truncate text-sm font-semibold text-foreground">
                    {g.name}
                  </h4>
                  {complete && (
                    <span className="inline-flex items-center gap-0.5 rounded-full bg-emerald-50 px-1.5 py-0.5 text-[10px] font-medium text-emerald-700">
                      <Check className="size-3" />
                      Logrado
                    </span>
                  )}
                </div>
                <p className="text-xs text-muted-foreground">
                  Meta: {formatCurrency(g.target)} · {formatDate(g.deadline)}
                </p>
              </div>
              <span className="text-sm font-semibold tabular-nums text-foreground">
                {formatPercent(progress)}
              </span>
            </div>

            <div className="relative h-2 overflow-hidden rounded-full bg-muted">
              <div
                className={cn("h-full rounded-full transition-all duration-700", tone.bar)}
                style={{ width: `${progress * 100}%` }}
              />
            </div>

            <div className="flex items-center justify-between text-xs">
              <span className="tabular-nums font-medium text-foreground">
                {formatCurrency(g.current)}
              </span>
              <span className="text-muted-foreground">
                {complete
                  ? "Objetivo alcanzado"
                  : `Faltan ${formatCurrency(g.target - g.current)}`}
              </span>
            </div>
          </article>
        );
      })}
    </div>
  );
}
