"use client";

import { useState } from "react";
import { TrendingUp } from "lucide-react";
import type { MonthlyPoint } from "@/lib/finance/types";
import {
  formatCurrency,
  formatCurrencyCompact,
} from "@/lib/finance/format";
import { cn } from "@/lib/utils";

interface MonthlyEvolutionChartProps {
  data: MonthlyPoint[];
}

const INCOME_COLOR = "#0d9488";
const EXPENSE_COLOR = "#fb7185";
const SAVINGS_COLOR = "#0d9488";

/** Gráfico de evolución mensual: barras de ingresos/gastos + línea de ahorro. */
export function MonthlyEvolutionChart({ data }: MonthlyEvolutionChartProps) {
  const [hover, setHover] = useState<number | null>(null);

  const width = 720;
  const height = 260;
  const padding = { top: 20, right: 16, bottom: 32, left: 48 };
  const innerW = width - padding.left - padding.right;
  const innerH = height - padding.top - padding.bottom;

  const max = Math.max(...data.flatMap((d) => [d.income, d.expenses])) * 1.12;
  const groupW = innerW / data.length;
  const barW = Math.min(14, groupW / 3.2);

  const yTicks = 4;
  const ticks = Array.from({ length: yTicks + 1 }, (_, i) => (max / yTicks) * i);

  // Línea de ahorro
  const savingsPoints = data.map((d, i) => {
    const x = padding.left + groupW * i + groupW / 2;
    const y = padding.top + innerH - (d.savings / max) * innerH;
    return [x, y] as const;
  });
  const savingsPath = savingsPoints
    .map(([x, y], i) => `${i === 0 ? "M" : "L"} ${x.toFixed(2)} ${y.toFixed(2)}`)
    .join(" ");

  return (
    <div className="relative">
      {/* Tooltip */}
      {hover !== null && (
        <div
          className="pointer-events-none absolute z-10 rounded-xl border bg-popover p-3 text-xs shadow-lg"
          style={{
            left: `calc(${(hover / (data.length - 1)) * 100}% )`,
            top: 0,
            transform: "translate(-50%, 0)",
          }}
        >
          <p className="mb-1.5 font-semibold text-foreground">
            {data[hover].month}
          </p>
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="size-2 rounded-full" style={{ background: INCOME_COLOR }} />
              <span className="text-muted-foreground">Ingresos</span>
              <span className="ml-auto font-medium tabular-nums text-foreground">
                {formatCurrency(data[hover].income)}
              </span>
            </div>
            <div className="flex items-center gap-2">
              <span className="size-2 rounded-full" style={{ background: EXPENSE_COLOR }} />
              <span className="text-muted-foreground">Gastos</span>
              <span className="ml-auto font-medium tabular-nums text-foreground">
                {formatCurrency(data[hover].expenses)}
              </span>
            </div>
            <div className="flex items-center gap-2 border-t pt-1">
              <span className="size-2 rounded-full" style={{ background: SAVINGS_COLOR }} />
              <span className="text-muted-foreground">Ahorro</span>
              <span className="ml-auto font-medium tabular-nums text-foreground">
                {formatCurrency(data[hover].savings)}
              </span>
            </div>
          </div>
        </div>
      )}

      <svg
        viewBox={`0 0 ${width} ${height}`}
        className="w-full"
        role="img"
        aria-label="Evolución mensual de ingresos, gastos y ahorro"
      >
        {/* Grid + etiquetas Y */}
        {ticks.map((t, i) => {
          const y = padding.top + innerH - (t / max) * innerH;
          return (
            <g key={i}>
              <line
                x1={padding.left}
                y1={y}
                x2={width - padding.right}
                y2={y}
                stroke="oklch(0.93 0.01 155)"
                strokeWidth={1}
                strokeDasharray={i === 0 ? "0" : "3 4"}
              />
              <text
                x={padding.left - 8}
                y={y + 3}
                textAnchor="end"
                className="fill-muted-foreground text-[10px]"
              >
                {formatCurrencyCompact(t)}
              </text>
            </g>
          );
        })}

        {/* Barras */}
        {data.map((d, i) => {
          const gx = padding.left + groupW * i + groupW / 2;
          const incomeH = (d.income / max) * innerH;
          const expenseH = (d.expenses / max) * innerH;
          const isHover = hover === i;
          return (
            <g
              key={d.month}
              onMouseEnter={() => setHover(i)}
              onMouseLeave={() => setHover(null)}
              className="cursor-pointer"
            >
              {/* área hover */}
              <rect
                x={gx - groupW / 2}
                y={padding.top}
                width={groupW}
                height={innerH}
                fill={isHover ? "oklch(0.96 0.01 155)" : "transparent"}
              />
              {/* barra ingresos */}
              <rect
                x={gx - barW - 2}
                y={padding.top + innerH - incomeH}
                width={barW}
                height={incomeH}
                rx={3}
                fill={INCOME_COLOR}
                opacity={isHover ? 1 : 0.9}
              />
              {/* barra gastos */}
              <rect
                x={gx + 2}
                y={padding.top + innerH - expenseH}
                width={barW}
                height={expenseH}
                rx={3}
                fill={EXPENSE_COLOR}
                opacity={isHover ? 1 : 0.9}
              />
              <text
                x={gx}
                y={height - 12}
                textAnchor="middle"
                className={cn(
                  "fill-muted-foreground text-[11px]",
                  isHover && "fill-foreground font-semibold"
                )}
              >
                {d.month}
              </text>
            </g>
          );
        })}

        {/* Línea de ahorro */}
        <path
          d={savingsPath}
          fill="none"
          stroke={SAVINGS_COLOR}
          strokeWidth={2}
          strokeLinecap="round"
          strokeLinejoin="round"
          strokeDasharray="2 0"
        />
        {savingsPoints.map(([x, y], i) => (
          <circle
            key={i}
            cx={x}
            cy={y}
            r={3}
            fill="white"
            stroke={SAVINGS_COLOR}
            strokeWidth={2}
          />
        ))}
      </svg>

      <div className="mt-3 flex flex-wrap items-center gap-4 text-xs text-muted-foreground">
        <span className="flex items-center gap-1.5">
          <span className="size-2.5 rounded-sm" style={{ background: INCOME_COLOR }} />
          Ingresos
        </span>
        <span className="flex items-center gap-1.5">
          <span className="size-2.5 rounded-sm" style={{ background: EXPENSE_COLOR }} />
          Gastos
        </span>
        <span className="flex items-center gap-1.5">
          <span className="size-2.5 rounded-full border-2 border-current" style={{ borderColor: SAVINGS_COLOR, color: SAVINGS_COLOR }} />
          Ahorro
        </span>
        <span className="ml-auto hidden items-center gap-1 text-emerald-700 sm:flex">
          <TrendingUp className="size-3.5" />
          Ahorro en alza 3 meses seguidos
        </span>
      </div>
    </div>
  );
}
