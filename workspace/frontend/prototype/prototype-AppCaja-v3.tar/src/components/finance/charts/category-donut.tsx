"use client";

import { useState } from "react";
import type { Category } from "@/lib/finance/types";
import { formatCurrency, formatPercent } from "@/lib/finance/format";
import { getIcon } from "@/lib/finance/icons";
import { cn } from "@/lib/utils";

interface CategoryDonutProps {
  categories: Category[];
}

interface Segment {
  id: string;
  color: string;
  dash: number;
  gap: number;
  offset: number;
  fraction: number;
}

/** Donut SVG de distribución de gastos con leyenda interactiva. */
export function CategoryDonut({ categories }: CategoryDonutProps) {
  const [active, setActive] = useState<string | null>(null);
  const total = categories.reduce((sum, c) => sum + c.amount, 0);

  const size = 180;
  const stroke = 22;
  const r = (size - stroke) / 2;
  const cx = size / 2;
  const cy = size / 2;
  const circumference = 2 * Math.PI * r;

  const segments = categories.reduce(
    (acc, c) => {
      const fraction = c.amount / total;
      const dash = fraction * circumference;
      acc.list.push({
        id: c.id,
        color: c.color,
        dash,
        gap: circumference - dash,
        offset: -acc.cumulative,
        fraction,
      });
      acc.cumulative += dash;
      return acc;
    },
    { list: [] as Segment[], cumulative: 0 }
  ).list;

  const activeCat = categories.find((c) => c.id === active) ?? null;
  const centerValue = activeCat ? activeCat.amount : total;
  const centerLabel = activeCat ? activeCat.name : "Gasto total";
  const centerPct = activeCat ? activeCat.amount / total : 1;

  return (
    <div className="flex flex-col items-center gap-6 sm:flex-row sm:items-center sm:gap-8">
      <div className="relative shrink-0">
        <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
          <circle
            cx={cx}
            cy={cy}
            r={r}
            fill="none"
            stroke="oklch(0.95 0.01 155)"
            strokeWidth={stroke}
          />
          {segments.map((s) => (
            <circle
              key={s.id}
              cx={cx}
              cy={cy}
              r={r}
              fill="none"
              stroke={s.color}
              strokeWidth={active === s.id ? stroke + 4 : stroke}
              strokeDasharray={`${s.dash} ${s.gap}`}
              strokeDashoffset={s.offset}
              strokeLinecap="butt"
              transform={`rotate(-90 ${cx} ${cy})`}
              className="cursor-pointer transition-all duration-200"
              opacity={active && active !== s.id ? 0.35 : 1}
              onMouseEnter={() => setActive(s.id)}
              onMouseLeave={() => setActive(null)}
            />
          ))}
        </svg>
        <div className="pointer-events-none absolute inset-0 flex flex-col items-center justify-center text-center">
          <span className="max-w-[110px] truncate text-[11px] text-muted-foreground">
            {centerLabel}
          </span>
          <span className="text-lg font-semibold tabular-nums text-foreground">
            {formatCurrency(centerValue)}
          </span>
          {activeCat && (
            <span className="text-[11px] font-medium text-emerald-700">
              {formatPercent(centerPct)} del total
            </span>
          )}
        </div>
      </div>

      <ul className="grid w-full grid-cols-1 gap-1.5 sm:grid-cols-1">
        {categories.map((c) => {
          const Icon = getIcon(c.icon);
          const isActive = active === c.id;
          return (
            <li key={c.id}>
              <button
                type="button"
                onMouseEnter={() => setActive(c.id)}
                onMouseLeave={() => setActive(null)}
                onFocus={() => setActive(c.id)}
                onBlur={() => setActive(null)}
                className={cn(
                  "flex w-full items-center gap-3 rounded-xl px-2.5 py-1.5 text-left transition-colors",
                  isActive ? "bg-muted" : "hover:bg-muted/60"
                )}
              >
                <span
                  className="grid size-7 shrink-0 place-items-center rounded-lg"
                  style={{ background: `${c.color}1a`, color: c.color }}
                >
                  <Icon className="size-3.5" />
                </span>
                <span className="flex-1 truncate text-sm font-medium text-foreground">
                  {c.name}
                </span>
                <span className="text-sm tabular-nums text-muted-foreground">
                  {formatPercent(c.amount / total)}
                </span>
                <span className="w-20 text-right text-sm font-semibold tabular-nums text-foreground">
                  {formatCurrency(c.amount)}
                </span>
              </button>
            </li>
          );
        })}
      </ul>
    </div>
  );
}
