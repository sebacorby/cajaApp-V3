"use client";

import { useState } from "react";
import { Menu, Plus, Bell, Search } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Sheet,
  SheetContent,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";
import { Sidebar } from "./sidebar";
import { Brand } from "./brand";
import {
  useFinanceUI,
  PERIOD_SHORT,
  type Period,
} from "@/lib/finance/ui-store";
import { financeSnapshot } from "@/lib/finance/mock-data";
import { cn } from "@/lib/utils";

const PERIODS: Period[] = ["mes", "trimestre", "semestre", "anio"];

/** Indicador de estado financiero general con punto semáforo. */
function StatusIndicator() {
  const score = financeSnapshot.healthScore;
  const tone = score >= 70 ? "emerald" : score >= 45 ? "amber" : "rose";
  const label = score >= 70 ? "Saludable" : score >= 45 ? "Atención" : "Crítico";
  const dot =
    tone === "emerald"
      ? "bg-emerald-500"
      : tone === "amber"
        ? "bg-amber-500"
        : "bg-rose-500";
  const ring =
    tone === "emerald"
      ? "text-emerald-700 bg-emerald-50 border-emerald-200"
      : tone === "amber"
        ? "text-amber-700 bg-amber-50 border-amber-200"
        : "text-rose-700 bg-rose-50 border-rose-200";
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-xs font-medium",
        ring
      )}
    >
      <span className={cn("size-1.5 rounded-full", dot)} />
      {label}
    </span>
  );
}

export function Header() {
  const period = useFinanceUI((s) => s.period);
  const setPeriod = useFinanceUI((s) => s.setPeriod);
  const [mobileOpen, setMobileOpen] = useState(false);
  const { user } = financeSnapshot;

  return (
    <header className="sticky top-0 z-30 border-b bg-background/80 backdrop-blur-md">
      <div className="flex items-center gap-3 px-4 py-3 sm:px-6 lg:px-8">
        {/* Trigger mobile */}
        <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
          <SheetTrigger asChild>
            <Button
              variant="ghost"
              size="icon"
              className="lg:hidden"
              aria-label="Abrir menú"
            >
              <Menu className="size-5" />
            </Button>
          </SheetTrigger>
          <SheetContent side="left" className="w-72 p-0">
            <SheetTitle className="sr-only">Navegación</SheetTitle>
            <Sidebar onNavigate={() => setMobileOpen(false)} />
          </SheetContent>
        </Sheet>

        {/* Marca en mobile */}
        <div className="lg:hidden">
          <Brand showText={false} />
        </div>

        {/* Saludo */}
        <div className="hidden flex-col leading-tight sm:flex">
          <span className="text-[13px] text-muted-foreground">
            {user.greeting} 👋
          </span>
          <span className="text-base font-semibold text-foreground">
            Así están tus finanzas
          </span>
        </div>

        <div className="ml-auto flex items-center gap-2">
          {/* Selector de período */}
          <Select
            value={period}
            onValueChange={(v) => setPeriod(v as Period)}
          >
            <SelectTrigger
              className="h-9 w-[140px] gap-1.5 rounded-full border bg-card text-sm sm:w-[168px]"
              aria-label="Seleccionar período"
            >
              <SelectValue />
            </SelectTrigger>
            <SelectContent align="end">
              {PERIODS.map((p) => (
                <SelectItem key={p} value={p}>
                  {PERIOD_SHORT[p]}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          <StatusIndicator />

          <Button
            variant="ghost"
            size="icon"
            className="hidden sm:inline-flex"
            aria-label="Buscar"
          >
            <Search className="size-[18px]" />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className="relative hidden sm:inline-flex"
            aria-label="Notificaciones"
          >
            <Bell className="size-[18px]" />
            <span className="absolute right-2 top-2 size-1.5 rounded-full bg-rose-500" />
          </Button>

          <Button size="sm" className="h-9 gap-1.5 rounded-full">
            <Plus className="size-4" />
            <span className="hidden sm:inline">Nuevo movimiento</span>
            <span className="sm:hidden">Nuevo</span>
          </Button>
        </div>
      </div>
    </header>
  );
}
