"use client";

import { useState } from "react";
import { FlaskConical, X, Loader2, Inbox, AlertTriangle, Check } from "lucide-react";
import { useFinanceUI, type UIMode } from "@/lib/finance/ui-store";
import { cn } from "@/lib/utils";

const MODES: { id: UIMode; label: string; icon: React.ElementType }[] = [
  { id: "normal", label: "Normal", icon: Check },
  { id: "loading", label: "Cargando", icon: Loader2 },
  { id: "empty", label: "Sin datos", icon: Inbox },
  { id: "error", label: "Error", icon: AlertTriangle },
];

/** Control flotante discreto para probar los estados de interfaz del prototipo. */
export function DemoStateControl() {
  const [open, setOpen] = useState(false);
  const mode = useFinanceUI((s) => s.mode);
  const setMode = useFinanceUI((s) => s.setMode);

  return (
    <div className="fixed bottom-4 right-4 z-40 flex flex-col items-end gap-2">
      {open && (
        <div className="flex flex-col gap-1 rounded-2xl border bg-popover p-2 shadow-lg">
          <div className="flex items-center justify-between px-2 pb-1 pt-1">
            <span className="flex items-center gap-1.5 text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">
              <FlaskConical className="size-3" />
              Estados de UI
            </span>
          </div>
          {MODES.map((m) => {
            const Icon = m.icon;
            const active = mode === m.id;
            return (
              <button
                key={m.id}
                type="button"
                onClick={() => setMode(m.id)}
                className={cn(
                  "flex items-center gap-2 rounded-lg px-3 py-1.5 text-xs font-medium transition-colors",
                  active
                    ? "bg-primary text-primary-foreground"
                    : "text-muted-foreground hover:bg-muted hover:text-foreground"
                )}
              >
                <Icon className={cn("size-3.5", m.id === "loading" && "animate-spin")} />
                {m.label}
              </button>
            );
          })}
        </div>
      )}
      <button
        type="button"
        onClick={() => setOpen((o) => !o)}
        className="grid size-11 place-items-center rounded-full border bg-card shadow-md transition-all hover:shadow-lg"
        aria-label="Abrir control de estados de demostración"
      >
        {open ? <X className="size-4" /> : <FlaskConical className="size-4 text-primary" />}
      </button>
    </div>
  );
}
