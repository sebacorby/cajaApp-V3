import { cn } from "@/lib/utils";

interface BrandProps {
  className?: string;
  showText?: boolean;
}

/** Marca del producto: ícono de hoja-escudo esmeralda + wordmark. */
export function Brand({ className, showText = true }: BrandProps) {
  return (
    <div className={cn("flex items-center gap-2.5", className)}>
      <div className="relative grid size-9 place-items-center rounded-xl bg-primary text-primary-foreground shadow-sm">
        <svg
          viewBox="0 0 24 24"
          fill="none"
          className="size-5"
          aria-hidden="true"
        >
          <path
            d="M12 3c3.5 2 6 3.5 6 7.5 0 4-2.5 7-6 8.5C8.5 17.5 6 14.5 6 10.5 6 6.5 8.5 5 12 3Z"
            fill="currentColor"
            opacity="0.35"
          />
          <path
            d="M12 6.5c2 1.4 3.5 2.6 3.5 5.2 0 1.7-.8 3-2 4-1-1.4-1.5-2.6-1.5-4 0-1.4.4-2.3 0-3.2-.4.5-.8 1-1 1.6-.3-.9-.7-1.8-1-2.6.7-.4 1.3-.7 2-1Z"
            fill="currentColor"
          />
        </svg>
      </div>
      {showText && (
        <div className="flex flex-col leading-none">
          <span className="text-[15px] font-semibold tracking-tight text-foreground">
            Clarified
          </span>
          <span className="text-[11px] text-muted-foreground">Finanzas personales</span>
        </div>
      )}
    </div>
  );
}
