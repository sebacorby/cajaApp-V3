"use client";

import { Sidebar } from "./sidebar";
import { Header } from "./header";
import { NAV_ITEMS } from "@/lib/finance/nav";
import { useFinanceUI } from "@/lib/finance/ui-store";
import { ShieldCheck } from "lucide-react";

interface AppShellProps {
  children: React.ReactNode;
}

export function AppShell({ children }: AppShellProps) {
  const section = useFinanceUI((s) => s.section);
  const activeLabel =
    NAV_ITEMS.find((n) => n.id === section)?.description ?? "Dashboard";

  return (
    <div className="flex min-h-screen flex-col bg-background">
      <div className="flex flex-1">
        {/* Sidebar de escritorio */}
        <aside className="hidden w-64 shrink-0 border-r bg-sidebar lg:block">
          <div className="sticky top-0 h-screen">
            <Sidebar />
          </div>
        </aside>

        {/* Contenido principal */}
        <div className="flex min-w-0 flex-1 flex-col">
          <Header />
          <main className="flex-1 px-4 py-6 sm:px-6 lg:px-8">
            <div className="mx-auto w-full max-w-7xl">
              <div className="mb-5">
                <p className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
                  {activeLabel}
                </p>
              </div>
              {children}
            </div>
          </main>

          {/* Footer sticky al fondo */}
          <footer className="mt-auto border-t bg-card/50">
            <div className="mx-auto flex w-full max-w-7xl flex-col items-start gap-2 px-4 py-5 text-xs text-muted-foreground sm:flex-row sm:items-center sm:justify-between sm:px-6 lg:px-8">
              <p>
                © 2025 Clarified · Prototipo de demostración con datos simulados.
              </p>
              <p className="flex items-center gap-1.5">
                <ShieldCheck className="size-3.5 text-emerald-600" />
                Información cifrada de extremo a extremo
              </p>
            </div>
          </footer>
        </div>
      </div>
    </div>
  );
}
