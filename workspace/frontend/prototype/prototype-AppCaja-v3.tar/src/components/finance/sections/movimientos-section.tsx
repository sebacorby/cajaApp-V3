"use client";

import { Download, Filter } from "lucide-react";
import { financeSnapshot } from "@/lib/finance/mock-data";
import { SectionCard } from "../dashboard/section-card";
import { TransactionsList } from "../transactions/transactions-list";
import { Button } from "@/components/ui/button";
import {
  formatCurrency,
  formatVariation,
} from "@/lib/finance/format";

export function MovimientosSection() {
  const { transactions, summary } = financeSnapshot;
  const net = summary.income - summary.expenses;

  return (
    <div className="flex flex-col gap-5">
      {/* Resumen rápido */}
      <div className="grid grid-cols-3 gap-3">
        <div className="rounded-2xl border bg-card p-4">
          <p className="text-xs text-muted-foreground">Ingresos</p>
          <p className="mt-1 text-lg font-semibold tabular-nums text-emerald-700">
            {formatCurrency(summary.income)}
          </p>
        </div>
        <div className="rounded-2xl border bg-card p-4">
          <p className="text-xs text-muted-foreground">Gastos</p>
          <p className="mt-1 text-lg font-semibold tabular-nums text-rose-700">
            {formatCurrency(summary.expenses)}
          </p>
        </div>
        <div className="rounded-2xl border bg-card p-4">
          <p className="text-xs text-muted-foreground">Balance neto</p>
          <p className="mt-1 text-lg font-semibold tabular-nums text-foreground">
            {formatCurrency(net)}
          </p>
        </div>
      </div>

      <SectionCard
        title="Historial de movimientos"
        description={`${transactions.length} transacciones registradas este período`}
        action={
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" className="gap-1.5">
              <Filter className="size-3.5" />
              <span className="hidden sm:inline">Filtros</span>
            </Button>
            <Button variant="outline" size="sm" className="gap-1.5">
              <Download className="size-3.5" />
              <span className="hidden sm:inline">Exportar</span>
            </Button>
          </div>
        }
      >
        <TransactionsList transactions={transactions} filterable />
      </SectionCard>
    </div>
  );
}
