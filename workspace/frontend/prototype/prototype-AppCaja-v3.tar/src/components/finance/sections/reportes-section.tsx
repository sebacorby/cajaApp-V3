"use client";

import { financeSnapshot } from "@/lib/finance/mock-data";
import { SectionCard } from "../dashboard/section-card";
import { MonthlyEvolutionChart } from "../charts/monthly-evolution-chart";
import { CategoryDonut } from "../charts/category-donut";
import {
  formatCurrency,
  formatPercent,
} from "@/lib/finance/format";
import { TrendingUp, TrendingDown, PiggyBank } from "lucide-react";

export function ReportesSection() {
  const { evolution, categories, summary } = financeSnapshot;
  const avgSavings =
    evolution.reduce((s, e) => s + e.savings, 0) / evolution.length;
  const avgExpenses =
    evolution.reduce((s, e) => s + e.expenses, 0) / evolution.length;
  const savingsRateAvg = avgSavings / (avgExpenses || 1);

  return (
    <div className="flex flex-col gap-5">
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
        <div className="flex items-center gap-3 rounded-2xl border bg-card p-5">
          <span className="grid size-10 place-items-center rounded-xl bg-emerald-50 text-emerald-600">
            <TrendingUp className="size-5" />
          </span>
          <div>
            <p className="text-xs text-muted-foreground">Ahorro promedio</p>
            <p className="text-lg font-semibold tabular-nums text-foreground">
              {formatCurrency(avgSavings)}
            </p>
          </div>
        </div>
        <div className="flex items-center gap-3 rounded-2xl border bg-card p-5">
          <span className="grid size-10 place-items-center rounded-xl bg-rose-50 text-rose-600">
            <TrendingDown className="size-5" />
          </span>
          <div>
            <p className="text-xs text-muted-foreground">Gasto promedio</p>
            <p className="text-lg font-semibold tabular-nums text-foreground">
              {formatCurrency(avgExpenses)}
            </p>
          </div>
        </div>
        <div className="flex items-center gap-3 rounded-2xl border bg-card p-5">
          <span className="grid size-10 place-items-center rounded-xl bg-teal-50 text-teal-600">
            <PiggyBank className="size-5" />
          </span>
          <div>
            <p className="text-xs text-muted-foreground">Tasa de ahorro media</p>
            <p className="text-lg font-semibold tabular-nums text-foreground">
              {formatPercent(savingsRateAvg)}
            </p>
          </div>
        </div>
      </div>

      <SectionCard
        title="Evolución de 7 meses"
        description="Comparativa de ingresos, gastos y ahorro mensual"
      >
        <MonthlyEvolutionChart data={evolution} />
      </SectionCard>

      <div className="grid grid-cols-1 gap-5 lg:grid-cols-2">
        <SectionCard
          title="Gastos por categoría"
          description="Distribución del mes actual"
        >
          <CategoryDonut categories={categories} />
        </SectionCard>
        <SectionCard
          title="Resumen del período"
          description="Indicadores clave"
        >
          <dl className="flex flex-col gap-3">
            {[
              { label: "Ingresos del mes", value: formatCurrency(summary.income), tone: "text-emerald-700" },
              { label: "Gastos del mes", value: formatCurrency(summary.expenses), tone: "text-rose-700" },
              { label: "Ahorro del mes", value: formatCurrency(summary.savings), tone: "text-foreground" },
              { label: "Tasa de ahorro", value: formatPercent(summary.savingsRate), tone: "text-emerald-700" },
              { label: "Balance disponible", value: formatCurrency(summary.balance), tone: "text-foreground" },
            ].map((row) => (
              <div
                key={row.label}
                className="flex items-center justify-between border-b pb-3 last:border-0 last:pb-0"
              >
                <dt className="text-sm text-muted-foreground">{row.label}</dt>
                <dd className={`text-sm font-semibold tabular-nums ${row.tone}`}>
                  {row.value}
                </dd>
              </div>
            ))}
          </dl>
        </SectionCard>
      </div>
    </div>
  );
}
