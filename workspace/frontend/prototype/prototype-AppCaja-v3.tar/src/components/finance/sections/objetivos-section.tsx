"use client";

import { Plus, Target } from "lucide-react";
import { financeSnapshot } from "@/lib/finance/mock-data";
import { SectionCard } from "../dashboard/section-card";
import { GoalsGrid } from "../goals/goals-grid";
import { Button } from "@/components/ui/button";
import { formatCurrency } from "@/lib/finance/format";

export function ObjetivosSection() {
  const { goals } = financeSnapshot;
  const totalTarget = goals.reduce((s, g) => s + g.target, 0);
  const totalCurrent = goals.reduce((s, g) => s + g.current, 0);

  return (
    <div className="flex flex-col gap-5">
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
        <div className="rounded-2xl border bg-card p-5">
          <p className="text-xs text-muted-foreground">Objetivos activos</p>
          <p className="mt-1 text-2xl font-semibold tabular-nums text-foreground">
            {goals.length}
          </p>
        </div>
        <div className="rounded-2xl border bg-card p-5">
          <p className="text-xs text-muted-foreground">Total ahorrado</p>
          <p className="mt-1 text-2xl font-semibold tabular-nums text-emerald-700">
            {formatCurrency(totalCurrent)}
          </p>
        </div>
        <div className="rounded-2xl border bg-card p-5">
          <p className="text-xs text-muted-foreground">Meta total</p>
          <p className="mt-1 text-2xl font-semibold tabular-nums text-foreground">
            {formatCurrency(totalTarget)}
          </p>
        </div>
      </div>

      <SectionCard
        title="Tus objetivos financieros"
        description="Metas de ahorro con seguimiento de progreso"
        action={
          <Button size="sm" className="gap-1.5">
            <Plus className="size-4" />
            <span className="hidden sm:inline">Nuevo objetivo</span>
          </Button>
        }
      >
        <div className="flex flex-col gap-4">
          <div className="flex items-center gap-2 rounded-xl bg-muted/40 p-3 text-sm text-muted-foreground">
            <Target className="size-4 text-primary" />
            Definí objetivos claros para mantener el foco en tu ahorro.
          </div>
          <GoalsGrid goals={goals} />
        </div>
      </SectionCard>
    </div>
  );
}
