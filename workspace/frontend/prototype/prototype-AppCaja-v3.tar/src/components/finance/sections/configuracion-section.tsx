"use client";

import { SectionCard } from "../dashboard/section-card";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import {
  Bell,
  Lock,
  Globe,
  Moon,
  Shield,
  CreditCard,
  LogOut,
} from "lucide-react";

function SettingRow({
  icon: Icon,
  title,
  description,
  action,
}: {
  icon: React.ElementType;
  title: string;
  description: string;
  action: React.ReactNode;
}) {
  return (
    <div className="flex items-center justify-between gap-4 border-b py-4 last:border-0 last:pb-0">
      <div className="flex items-start gap-3">
        <span className="grid size-9 shrink-0 place-items-center rounded-xl bg-muted text-muted-foreground">
          <Icon className="size-[18px]" />
        </span>
        <div>
          <p className="text-sm font-medium text-foreground">{title}</p>
          <p className="text-xs text-muted-foreground">{description}</p>
        </div>
      </div>
      {action}
    </div>
  );
}

export function ConfiguracionSection() {
  return (
    <div className="flex flex-col gap-5">
      <SectionCard
        title="Preferencias generales"
        description="Personalizá tu experiencia en la app"
      >
        <div className="flex flex-col">
          <SettingRow
            icon={Bell}
            title="Notificaciones de gastos"
            description="Recibí alertas al superar el 80 % de un presupuesto"
            action={<Switch defaultChecked />}
          />
          <SettingRow
            icon={Shield}
            title="Autenticación en dos pasos"
            description="Mayor seguridad al iniciar sesión"
            action={<Switch defaultChecked />}
          />
          <SettingRow
            icon={Moon}
            title="Modo oscuro"
            description="Cambia la apariencia a un tema oscuro"
            action={<Switch />}
          />
          <SettingRow
            icon={Globe}
            title="Moneda y región"
            description="ARS · Argentina (es-AR)"
            action={
              <Button variant="outline" size="sm">
                Cambiar
              </Button>
            }
          />
        </div>
      </SectionCard>

      <SectionCard
        title="Seguridad y cuenta"
        description="Gestioná el acceso a tu cuenta"
      >
        <div className="flex flex-col">
          <SettingRow
            icon={Lock}
            title="Cambiar contraseña"
            description="Última actualización hace 3 meses"
            action={
              <Button variant="outline" size="sm">
                Actualizar
              </Button>
            }
          />
          <SettingRow
            icon={CreditCard}
            title="Cuentas vinculadas"
            description="2 cuentas bancarias conectadas"
            action={
              <Button variant="outline" size="sm">
                Gestionar
              </Button>
            }
          />
          <SettingRow
            icon={LogOut}
            title="Cerrar sesión"
            description="Salí de tu cuenta en este dispositivo"
            action={
              <Button variant="ghost" size="sm" className="text-rose-600">
                Cerrar sesión
              </Button>
            }
          />
        </div>
      </SectionCard>

      <div className="rounded-2xl border border-dashed bg-muted/30 p-4 text-xs text-muted-foreground">
        <Label className="text-xs font-medium text-foreground">
          Sobre el prototipo
        </Label>
        <p className="mt-1">
          Esta es una demostración visual. Los datos son simulados y no se
          envían a ningún servidor. Clarified no constituye asesoramiento
          financiero profesional.
        </p>
      </div>
    </div>
  );
}
