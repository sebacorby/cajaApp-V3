"use client";

import { Plus, Wallet } from "lucide-react";
import { financeSnapshot } from "@/lib/finance/mock-data";
import { SectionCard } from "../dashboard/section-card";
import { BudgetProgress } from "../dashboard/budget-progress";
import { Button } from "@/components/ui/button";
import {
  formatCurrency,
  formatPercent,
  computeProgress,
} from "@/lib/finance/format";

export function PresupuestosSection() {
  const { budgets, budgetSummary } = financeSnapshot;
  const progress = computeProgress(budgetSummary.totalSpent, budgetSummary.totalLimit);

  return (
    <div className="flex flex-col gap-5">
      {/* Resumen general */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
        <div className="rounded-2xl border bg-card p-5">
          <p className="text-xs text-muted-foreground">Presupuesto total</p>
          <p className="mt-1 text-2xl font-semibold tabular-nums text-foreground">
            {formatCurrency(budgetSummary.totalLimit)}
          </p>
        </div>
        <div className="rounded-2xl border bg-card p-5">
          <p className="text-xs text-muted-foreground">Gastado</p>
          <p className="mt-1 text-2xl font-semibold tabular-nums text-rose-700">
            {formatCurrency(budgetSummary.totalSpent)}
          </p>
        </div>
        <div className="rounded-2xl border bg-card p-5">
          <p className="text-xs text-muted-foreground">Disponible</p>
          <p className="mt-1 text-2xl font-semibold tabular-nums text-emerald-700">
            {formatCurrency(budgetSummary.totalLimit - budgetSummary.totalSpent)}
          </p>
        </div>
      </div>

      {/* Barra global */}
      <div className="rounded-2xl border bg-card p-5">
        <div className="mb-2 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="grid size-8 place-items-center rounded-lg bg-primary/10 text-primary">
              <Wallet className="size-4" />
            </span>
            <p className="text-sm font-medium text-foreground">
              Avance general del mes
            </p>
          </div>
          <span className="text-sm font-semibold tabular-nums text-foreground">
            {formatPercent(progress)}
          </span>
        </div>
        <div className="relative h-2.5 overflow-hidden rounded-full bg-muted">
          <div
            className="h-full rounded-full bg-primary transition-all duration-700"
            style={{ width: `${Math.min(progress * 100, 100)}%` }}
          />
        </div>
      </div>

      <SectionCard
        title="Presupuestos por categoría"
        description="Definí límites mensuales y recibí alertas al acercarte"
        action={
          <Button size="sm" className="gap-1.5">
            <Plus className="size-4" />
            <span className="hidden sm:inline">Nuevo presupuesto</span>
          </Button>
        }
      >
        <BudgetProgress budgets={budgets} />
      </SectionCard>
    </div>
  );
}
