"use client";

import {
  TrendingUp,
  TrendingDown,
  PiggyBank,
  Wallet,
  ArrowRight,
  Sparkles,
} from "lucide-react";
import { financeSnapshot } from "@/lib/finance/mock-data";
import {
  formatCurrency,
  formatVariation,
  variationTone,
  formatPercent,
} from "@/lib/finance/format";
import { MetricCard } from "../dashboard/metric-card";
import { BalanceHero } from "../dashboard/balance-hero";
import { SavingsBudgetCard } from "../dashboard/savings-budget-card";
import { SectionCard } from "../dashboard/section-card";
import { SmartAlerts } from "../dashboard/smart-alerts";
import { GoalsGrid } from "../goals/goals-grid";
import { TransactionsList } from "../transactions/transactions-list";
import { MonthlyEvolutionChart } from "../charts/monthly-evolution-chart";
import { CategoryDonut } from "../charts/category-donut";
import { useFinanceUI } from "@/lib/finance/ui-store";
import { Button } from "@/components/ui/button";

export function DashboardSection() {
  const { summary, budgetSummary, categories, transactions, goals, alerts, evolution, user } =
    financeSnapshot;
  const setSection = useFinanceUI((s) => s.setSection);

  return (
    <div className="flex flex-col gap-5">
      {/* Fila 1: balance + ahorro/presupuesto */}
      <div className="grid grid-cols-1 gap-5 lg:grid-cols-3">
        <div className="lg:col-span-2">
          <BalanceHero summary={summary} account={user.account} />
        </div>
        <SavingsBudgetCard summary={summary} budget={budgetSummary} />
      </div>

      {/* Fila 2: métricas clave */}
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <MetricCard
          title="Ingresos del mes"
          value={formatCurrency(summary.income)}
          variation={formatVariation(summary.incomeVariation)}
          variationTone={variationTone(summary.incomeVariation)}
          icon={TrendingUp}
          iconClassName="bg-emerald-50 text-emerald-600"
          caption="vs. mes anterior"
          className="animate-fade-in-up"
        />
        <MetricCard
          title="Gastos del mes"
          value={formatCurrency(summary.expenses)}
          variation={formatVariation(summary.expensesVariation)}
          variationTone={variationTone(summary.expensesVariation)}
          invertTone
          icon={TrendingDown}
          iconClassName="bg-rose-50 text-rose-600"
          caption="vs. mes anterior"
          className="animate-fade-in-up [animation-delay:60ms]"
        />
        <MetricCard
          title="Ahorro estimado"
          value={formatCurrency(summary.savings)}
          variation={formatPercent(summary.savingsRate)}
          variationTone="positive"
          icon={PiggyBank}
          iconClassName="bg-teal-50 text-teal-600"
          caption="tasa de ahorro"
          className="animate-fade-in-up [animation-delay:120ms]"
        />
        <MetricCard
          title="Presupuesto usado"
          value={formatPercent(budgetSummary.totalSpent / budgetSummary.totalLimit)}
          variation={`${formatCurrency(budgetSummary.totalLimit - budgetSummary.totalSpent)} libre`}
          variationTone={
            budgetSummary.totalSpent > budgetSummary.totalLimit ? "negative" : "neutral"
          }
          icon={Wallet}
          iconClassName="bg-amber-50 text-amber-600"
          caption="del límite mensual"
          className="animate-fade-in-up [animation-delay:180ms]"
        />
      </div>

      {/* Fila 3: evolución + categorías */}
      <div className="grid grid-cols-1 gap-5 lg:grid-cols-3">
        <div className="lg:col-span-2">
          <SectionCard
            title="Evolución mensual"
            description="Ingresos, gastos y ahorro de los últimos 7 meses"
            action={
              <Button
                variant="ghost"
                size="sm"
                className="gap-1 text-muted-foreground"
                onClick={() => setSection("reportes")}
              >
                Ver reportes
                <ArrowRight className="size-3.5" />
              </Button>
            }
          >
            <MonthlyEvolutionChart data={evolution} />
          </SectionCard>
        </div>
        <SectionCard
          title="Distribución de gastos"
          description="Por categoría este mes"
        >
          <CategoryDonut categories={categories} />
        </SectionCard>
      </div>

      {/* Fila 4: alertas + objetivos */}
      <div className="grid grid-cols-1 gap-5 lg:grid-cols-3">
        <SectionCard
          title="Alertas inteligentes"
          description="Recomendaciones automáticas"
          action={
            <span className="flex items-center gap-1 rounded-full bg-primary/10 px-2 py-0.5 text-xs font-medium text-primary">
              <Sparkles className="size-3" />
              {alerts.length}
            </span>
          }
        >
          <SmartAlerts alerts={alerts} />
        </SectionCard>
        <div className="lg:col-span-2">
          <SectionCard
            title="Objetivos financieros"
            description="Progreso de tus metas de ahorro"
            action={
              <Button
                variant="ghost"
                size="sm"
                className="gap-1 text-muted-foreground"
                onClick={() => setSection("objetivos")}
              >
                Ver todos
                <ArrowRight className="size-3.5" />
              </Button>
            }
          >
            <GoalsGrid goals={goals.slice(0, 4)} />
          </SectionCard>
        </div>
      </div>

      {/* Fila 5: últimos movimientos */}
      <SectionCard
        title="Últimos movimientos"
        description="Tus transacciones más recientes"
        action={
          <Button
            variant="ghost"
            size="sm"
            className="gap-1 text-muted-foreground"
            onClick={() => setSection("movimientos")}
          >
            Ver todos
            <ArrowRight className="size-3.5" />
          </Button>
        }
      >
        <TransactionsList transactions={transactions} limit={6} />
      </SectionCard>
    </div>
  );
}
